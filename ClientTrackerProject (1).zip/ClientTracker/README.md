# Client Tracker (Android)

Offline-first client tracker:
- Save clients (name, phone, notes)
- Log visits
- Predict next expected visit date using median of gaps (distinct LocalDate) rules
- Daily due-summary notifications via WorkManager
- Import/Export CSV + JSON via SAF

## Build

Prereqs:
- Android Studio (latest)
- Android SDK Platform 36 installed

Commands:
```bash
./gradlew test
./gradlew lint
./gradlew assembleDebug
```

Debug APK output:
- `app/build/outputs/apk/debug/app-debug.apk`

## Release (AAB)

1) Generate keystore:
```bash
keytool -genkeypair -v -keystore clienttracker-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias clienttracker
```

2) Add signing config to `app/build.gradle.kts` (replace values) and run:
```bash
./gradlew bundleRelease
```

Output:
- `app/build/outputs/bundle/release/app-release.aab`
