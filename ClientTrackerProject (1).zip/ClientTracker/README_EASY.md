# Client Tracker (Easy Install)

## Fastest way to get the APK (no Android Studio needed)

This project includes a GitHub Action that builds the debug APK for you.

### Steps (browser-only)
1) Create a free GitHub account.
2) Create a new repository (any name is fine).
3) Upload the project files to that repository:
   - Download `ClientTrackerProject.zip` from ChatGPT.
   - Unzip it.
   - Upload the **contents** of the `ClientTracker/` folder into the repo (not the outer zip itself).
4) In your repo, go to **Actions** → select **Build Debug APK** → **Run workflow**.
5) When it finishes, open the workflow run and download the artifact:
   - `client-tracker-debug-apk`
   - Inside it you will find `app-debug.apk`
6) Copy `app-debug.apk` to your Android phone and install it.

### Install on Android 16
- Settings → Apps → Special app access → Install unknown apps
- Choose Files / Chrome (whichever you used to open the APK)
- Allow from this source
- Tap APK → Install → Open

## Local build (if someone can do it on a PC)
```bash
./gradlew test
./gradlew lint
./gradlew assembleDebug
```
APK output:
`app/build/outputs/apk/debug/app-debug.apk`
