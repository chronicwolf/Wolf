package com.wolf.clienttracker

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import org.junit.Rule
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId

@HiltAndroidTest
class ClientFlowTest {

    @get:Rule(order = 0)
    val hiltRule = HiltAndroidRule(this)

    @get:Rule(order = 1)
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun addClient_logVisit_showsNextExpectedDate() {
        hiltRule.inject()

        // Onboarding may show on first run
        if (composeRule.onAllNodesWithTag("onboarding_skip").fetchSemanticsNodes().isNotEmpty()) {
            composeRule.onNodeWithTag("onboarding_skip").performClick()
        }

        composeRule.onNodeWithText("Add").performClick()

        composeRule.onNodeWithTag("client_name").performTextInput("Test Client")
        composeRule.onNodeWithTag("client_phone").performTextInput("+973 33-123-456")

        composeRule.onNodeWithText("Save").performClick()

        // log visit
        composeRule.onNodeWithTag("log_visit_button").performClick()
        composeRule.onNodeWithText("Log").performClick()

        val expected = LocalDate.now(ZoneId.systemDefault()).plusDays(21).toString()

        composeRule.waitUntil(5_000) {
            composeRule.onAllNodesWithTag("prediction_next_expected").fetchSemanticsNodes().isNotEmpty()
        }

        composeRule.onNodeWithTag("prediction_next_expected").assertIsDisplayed()
        composeRule.onNodeWithTag("prediction_next_expected").assertTextContains(expected)
    }
}
