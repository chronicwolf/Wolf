package com.wolf.clienttracker.ui.nav

sealed class AppRoute(val route: String) {
    data object Home : AppRoute("home")
    data object Clients : AppRoute("clients")
    data object Settings : AppRoute("settings")
    data object DueClients : AppRoute("due_clients")

    data object ClientProfile : AppRoute("client/{clientId}") {
        fun createRoute(clientId: Long) = "client/$clientId"
        const val ARG_ID = "clientId"
    }

    data object AddEditClient : AppRoute("add_edit_client?clientId={clientId}") {
        const val ARG_ID = "clientId"
        fun createRoute(clientId: Long?): String = if (clientId == null) "add_edit_client" else "add_edit_client?clientId=$clientId"
    }
}
