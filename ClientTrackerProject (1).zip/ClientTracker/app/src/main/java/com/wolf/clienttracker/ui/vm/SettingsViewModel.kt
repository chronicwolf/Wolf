package com.wolf.clienttracker.ui.vm

import android.content.Context
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wolf.clienttracker.data.io.ExportImportManager
import com.wolf.clienttracker.domain.usecase.GetAllClientsWithVisitsOnceUseCase
import com.wolf.clienttracker.data.settings.SettingsRepository
import com.wolf.clienttracker.domain.prediction.DueStatus
import com.wolf.clienttracker.domain.prediction.PredictionSettings
import com.wolf.clienttracker.domain.service.ClientPredictionService
import com.wolf.clienttracker.domain.time.TimeProvider
import com.wolf.clienttracker.notifications.NotificationHelper
import com.wolf.clienttracker.ui.common.UiEvent
import com.wolf.clienttracker.worker.NotificationScheduler
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Instant
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsRepository: SettingsRepository,
    private val getAllClientsWithVisitsOnce: GetAllClientsWithVisitsOnceUseCase,
    private val predictionService: ClientPredictionService,
    private val timeProvider: TimeProvider,
    private val scheduler: NotificationScheduler,
    private val ioManager: ExportImportManager,
) : ViewModel() {

    private val _events = MutableSharedFlow<UiEvent>()
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    data class SettingsState(
        val globalDefaultIntervalDays: Int = 21,
        val dueSoonWindowDays: Int = 3,
        val intervalsToConsider: Int = 5,
        val notificationsEnabled: Boolean = true,
        val notificationTimeMinutes: Int = 600,
    )

    val state: StateFlow<SettingsState> = combine(
        settingsRepository.globalDefaultIntervalDays,
        settingsRepository.dueSoonWindowDays,
        settingsRepository.intervalsToConsider,
        settingsRepository.notificationsEnabled,
        settingsRepository.notificationTimeMinutes,
    ) { global, dueSoon, n, enabled, time ->
        SettingsState(
            globalDefaultIntervalDays = global,
            dueSoonWindowDays = dueSoon,
            intervalsToConsider = n,
            notificationsEnabled = enabled,
            notificationTimeMinutes = time,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsState())

    data class IoState(
        val isWorking: Boolean = false,
        val lastMessage: String? = null,
        val lastImportSummary: ExportImportManager.ImportSummary? = null,
    )

    private val _ioState = MutableStateFlow(IoState())
    val ioState: StateFlow<IoState> = _ioState

    fun setGlobalDefaultIntervalDays(v: Int) {
        viewModelScope.launch { settingsRepository.setGlobalDefaultIntervalDays(v) }
    }

    fun setDueSoonWindowDays(v: Int) {
        viewModelScope.launch { settingsRepository.setDueSoonWindowDays(v) }
    }

    fun setIntervalsToConsider(v: Int) {
        viewModelScope.launch { settingsRepository.setIntervalsToConsider(v) }
    }

    fun setNotificationsEnabled(v: Boolean) {
        viewModelScope.launch {
            settingsRepository.setNotificationsEnabled(v)
            if (v) scheduler.scheduleDaily() else scheduler.cancel()
        }
    }

    fun setNotificationTimeMinutes(v: Int) {
        viewModelScope.launch {
            settingsRepository.setNotificationTimeMinutes(v)
            scheduler.scheduleDaily()
        }
    }

    fun runDueCheckNow() {
        scheduler.enqueueNow()
    }

    fun sendTestNotificationNow() {
        viewModelScope.launch {
            val canNotify = if (Build.VERSION.SDK_INT >= 33) {
                ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
            } else true

            if (!canNotify) {
                _events.emit(UiEvent.Message("Notification permission not granted."))
                return@launch
            }

            val settings = PredictionSettings(
                globalDefaultIntervalDays = settingsRepository.globalDefaultIntervalDays.first(),
                dueSoonWindowDays = settingsRepository.dueSoonWindowDays.first(),
                intervalsToConsider = settingsRepository.intervalsToConsider.first(),
            )

            val clients = getAllClientsWithVisitsOnce()
            val today = timeProvider.todayLocalDate()
            val preds = clients.map { predictionService.compute(it, todayOverride = today, settings = settings) }

            val overdue = clients.zip(preds).filter { it.second.status == DueStatus.OVERDUE }
            val dueSoon = clients.zip(preds).filter { it.second.status == DueStatus.DUE_SOON }

            val names = buildList {
                overdue.forEach { add(it.first.client.name) }
                dueSoon.forEach { add(it.first.client.name) }
            }

            NotificationHelper.postDueSummary(context, overdue.size, dueSoon.size, names)
            settingsRepository.setLastNotificationSentEpochMillis(timeProvider.nowInstant().toEpochMilli())
            _events.emit(UiEvent.Message("Test notification sent."))
        }
    }

    fun exportJson(uri: android.net.Uri) {
        viewModelScope.launch {
            _ioState.value = IoState(isWorking = true, lastMessage = null, lastImportSummary = null)
            val res = ioManager.exportJson(uri)
            _ioState.value = IoState(isWorking = false, lastMessage = if (res.isSuccess) "Exported JSON." else (res.exceptionOrNull()?.message ?: "Export failed"))
        }
    }

    fun exportCsv(uri: android.net.Uri) {
        viewModelScope.launch {
            _ioState.value = IoState(isWorking = true, lastMessage = null, lastImportSummary = null)
            val res = ioManager.exportCsv(uri)
            _ioState.value = IoState(isWorking = false, lastMessage = if (res.isSuccess) "Exported CSV." else (res.exceptionOrNull()?.message ?: "Export failed"))
        }
    }

    fun import(uri: android.net.Uri) {
        viewModelScope.launch {
            _ioState.value = IoState(isWorking = true, lastMessage = null, lastImportSummary = null)
            val res = ioManager.importFrom(uri)
            _ioState.value = if (res.isSuccess) {
                IoState(isWorking = false, lastMessage = "Import completed.", lastImportSummary = res.getOrThrow())
            } else {
                IoState(isWorking = false, lastMessage = res.exceptionOrNull()?.message ?: "Import failed", lastImportSummary = null)
            }
        }
    }
}
