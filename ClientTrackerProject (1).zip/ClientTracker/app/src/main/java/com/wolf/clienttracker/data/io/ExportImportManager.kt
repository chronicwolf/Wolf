package com.wolf.clienttracker.data.io

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import com.wolf.clienttracker.data.repo.ClientRepository
import com.wolf.clienttracker.domain.model.ClientWithVisits
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ExportImportManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: ClientRepository,
) {

    data class ImportSummary(
        val clientsAdded: Int,
        val duplicatesSkipped: Int,
        val visitsAdded: Int,
        val visitsSkipped: Int,
    )

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }

    suspend fun exportJson(uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val data = repository.getAllClientsWithVisitsOnce()
            val dto = ExportJson(
                schemaVersion = 1,
                exportedAtEpochMillis = Instant.now().toEpochMilli(),
                clients = data.map { it.toDto() },
            )
            context.contentResolver.openOutputStream(uri)?.use { os ->
                OutputStreamWriter(os).use { it.write(json.encodeToString(dto)) }
            } ?: error("Unable to open output stream")
        }
    }

    suspend fun exportCsv(uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val data = repository.getAllClientsWithVisitsOnce()
            context.contentResolver.openOutputStream(uri)?.use { os ->
                OutputStreamWriter(os).use { w ->
                    w.appendLine("# ClientTracker CSV")
                    w.appendLine("# schemaVersion=1")
                    w.appendLine("client_name,normalized_phone,display_phone,client_notes,client_created_at_epoch_millis,visit_timestamp_epoch_millis,visit_notes")
                    for (c in data) {
                        if (c.visits.isEmpty()) {
                            w.appendLine(csvRow(c, null))
                        } else {
                            for (v in c.visits) {
                                w.appendLine(csvRow(c, v))
                            }
                        }
                    }
                }
            } ?: error("Unable to open output stream")
        }
    }

    suspend fun importFrom(uri: Uri): Result<ImportSummary> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            val text = resolver.openInputStream(uri)?.use { input ->
                InputStreamReader(input).readText()
            } ?: error("Unable to open input stream")

            return@runCatching if (looksLikeJson(text)) {
                importJsonText(text)
            } else {
                importCsvText(text)
            }
        }
    }

    private fun looksLikeJson(text: String): Boolean {
        val t = text.trimStart()
        return t.startsWith("{") || t.startsWith("[")
    }

    private suspend fun importJsonText(text: String): ImportSummary {
        val dto = json.decodeFromString(ExportJson.serializer(), text)
        require(dto.schemaVersion == 1) { "Unsupported schemaVersion: ${dto.schemaVersion}" }

        var clientsAdded = 0
        var duplicatesSkipped = 0
        var visitsAdded = 0
        var visitsSkipped = 0

        for (c in dto.clients) {
            val existing = repository.findClientByNormalizedPhone(c.normalizedPhone)
            val clientId = if (existing == null) {
                val newId = repository.addClient(
                    name = c.name,
                    normalizedPhone = c.normalizedPhone,
                    displayPhone = c.displayPhone,
                    notes = c.notes,
                    createdAt = Instant.ofEpochMilli(c.createdAtEpochMillis),
                ).getOrThrow()
                clientsAdded++
                newId
            } else {
                duplicatesSkipped++
                existing.id
            }

            for (v in c.visits) {
                val added = repository.importVisit(clientId, Instant.ofEpochMilli(v.timestampEpochMillis), v.notes)
                if (added) visitsAdded++ else visitsSkipped++
            }
        }

        return ImportSummary(
            clientsAdded = clientsAdded,
            duplicatesSkipped = duplicatesSkipped,
            visitsAdded = visitsAdded,
            visitsSkipped = visitsSkipped,
        )
    }

    private suspend fun importCsvText(text: String): ImportSummary {
        var clientsAdded = 0
        var duplicatesSkipped = 0
        var visitsAdded = 0
        var visitsSkipped = 0

        val reader = BufferedReader(text.reader())
        var headerSeen = false
        reader.lineSequence().forEach { line ->
            val trimmed = line.trim()
            if (trimmed.isBlank() || trimmed.startsWith("#")) return@forEach
            if (!headerSeen) {
                headerSeen = true
                return@forEach // skip header row
            }
            val cols = parseCsvLine(line)
            if (cols.size < 7) return@forEach

            val clientName = cols[0]
            val normalizedPhone = cols[1]
            val displayPhone = cols[2]
            val notes = cols[3].ifBlank { null }
            val createdAt = cols[4].toLongOrNull() ?: Instant.now().toEpochMilli()

            val visitTs = cols[5].toLongOrNull()
            val visitNotes = cols[6].ifBlank { null }

            val existing = repository.findClientByNormalizedPhone(normalizedPhone)
            val clientId = if (existing == null) {
                val newId = repository.addClient(
                    name = clientName,
                    normalizedPhone = normalizedPhone,
                    displayPhone = displayPhone,
                    notes = notes,
                    createdAt = Instant.ofEpochMilli(createdAt),
                ).getOrThrow()
                clientsAdded++
                newId
            } else {
                duplicatesSkipped++
                existing.id
            }

            if (visitTs != null) {
                val added = repository.importVisit(clientId, Instant.ofEpochMilli(visitTs), visitNotes)
                if (added) visitsAdded++ else visitsSkipped++
            }
        }

        return ImportSummary(
            clientsAdded = clientsAdded,
            duplicatesSkipped = duplicatesSkipped,
            visitsAdded = visitsAdded,
            visitsSkipped = visitsSkipped,
        )
    }

    private fun csvRow(c: ClientWithVisits, v: com.wolf.clienttracker.domain.model.Visit?): String {
        fun esc(s: String?): String {
            val value = s ?: ""
            val needsQuotes = value.contains(',') || value.contains('"') || value.contains('\n')
            val escaped = value.replace("\"", "\"\"")
            return if (needsQuotes) "\"$escaped\"" else escaped
        }

        return listOf(
            esc(c.client.name),
            esc(c.client.normalizedPhone),
            esc(c.client.displayPhone),
            esc(c.client.notes),
            esc(c.client.createdAt.toEpochMilli().toString()),
            esc(v?.timestamp?.toEpochMilli()?.toString() ?: ""),
            esc(v?.notes ?: ""),
        ).joinToString(",")
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = ArrayList<String>()
        val sb = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' -> {
                    if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                        sb.append('"')
                        i++
                    } else {
                        inQuotes = !inQuotes
                    }
                }
                c == ',' && !inQuotes -> {
                    result.add(sb.toString())
                    sb.clear()
                }
                else -> sb.append(c)
            }
            i++
        }
        result.add(sb.toString())
        return result
    }

    @Serializable
    private data class ExportJson(
        val schemaVersion: Int,
        val exportedAtEpochMillis: Long,
        val clients: List<ClientDto>,
    )

    @Serializable
    private data class ClientDto(
        val name: String,
        val normalizedPhone: String,
        val displayPhone: String,
        val notes: String? = null,
        val createdAtEpochMillis: Long,
        val visits: List<VisitDto> = emptyList(),
    )

    @Serializable
    private data class VisitDto(
        val timestampEpochMillis: Long,
        val notes: String? = null,
    )

    private fun ClientWithVisits.toDto(): ClientDto {
        return ClientDto(
            name = client.name,
            normalizedPhone = client.normalizedPhone,
            displayPhone = client.displayPhone,
            notes = client.notes,
            createdAtEpochMillis = client.createdAt.toEpochMilli(),
            visits = visits.map { VisitDto(timestampEpochMillis = it.timestamp.toEpochMilli(), notes = it.notes) },
        )
    }
}
