package com.wolf.clienttracker.ui.vm

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wolf.clienttracker.domain.usecase.AddClientUseCase
import com.wolf.clienttracker.domain.usecase.ObserveClientWithVisitsUseCase
import com.wolf.clienttracker.domain.usecase.UpdateClientUseCase
import com.wolf.clienttracker.domain.phone.PhoneNormalizer
import com.wolf.clienttracker.domain.time.TimeProvider
import com.wolf.clienttracker.ui.common.UiEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AddEditClientViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val observeClientWithVisits: ObserveClientWithVisitsUseCase,
    private val addClientUseCase: AddClientUseCase,
    private val updateClientUseCase: UpdateClientUseCase,
    private val timeProvider: TimeProvider,
) : ViewModel() {

    private val clientId: Long? = savedStateHandle.get<Long>("clientId")?.takeIf { it > 0 }

    private val _name = MutableStateFlow("")
    val name: StateFlow<String> = _name

    private val _phone = MutableStateFlow("")
    val phone: StateFlow<String> = _phone

    private val _notes = MutableStateFlow("")
    val notes: StateFlow<String> = _notes

    private val _isLoading = MutableStateFlow(clientId != null)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _events = MutableSharedFlow<UiEvent>()
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    init {
        if (clientId != null) {
            viewModelScope.launch {
                observeClientWithVisits(clientId)
                    .filterNotNull()
                    .take(1)
                    .collect { c ->
                        _name.value = c.client.name
                        _phone.value = c.client.displayPhone
                        _notes.value = c.client.notes.orEmpty()
                        _isLoading.value = false
                    }
            }
        }
    }

    fun setName(value: String) { _name.value = value }
    fun setPhone(value: String) { _phone.value = value }
    fun setNotes(value: String) { _notes.value = value }

    fun save(onDone: (Long) -> Unit) {
        viewModelScope.launch {
            val name = _name.value.trim()
            if (name.length < 2) {
                _events.emit(UiEvent.Message("Name must be at least 2 characters."))
                return@launch
            }
            val normalized = PhoneNormalizer.normalize(_phone.value) ?: run {
                _events.emit(UiEvent.Message("Phone is required."))
                return@launch
            }
            val notes = _notes.value.trim().ifBlank { null }

            if (clientId == null) {
                val res = addClientUseCase(
                    name = name,
                    normalizedPhone = normalized.normalizedPhone,
                    displayPhone = normalized.displayPhone,
                    notes = notes,
                    createdAt = timeProvider.nowInstant(),
                )
                if (res.isSuccess) {
                    onDone(res.getOrThrow())
                } else {
                    _events.emit(UiEvent.Message(res.exceptionOrNull()?.message ?: "Failed"))
                }
            } else {
                val res = updateClientUseCase(
                    id = clientId,
                    name = name,
                    normalizedPhone = normalized.normalizedPhone,
                    displayPhone = normalized.displayPhone,
                    notes = notes,
                )
                if (res.isSuccess) {
                    onDone(clientId)
                } else {
                    _events.emit(UiEvent.Message(res.exceptionOrNull()?.message ?: "Failed"))
                }
            }
        }
    }
}
