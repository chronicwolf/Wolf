package com.wolf.clienttracker.di

import android.content.Context
import androidx.room.Room
import com.wolf.clienttracker.data.db.AppDatabase
import com.wolf.clienttracker.data.db.ClientDao
import com.wolf.clienttracker.data.db.VisitDao
import com.wolf.clienttracker.domain.time.SystemTimeProvider
import com.wolf.clienttracker.domain.time.TimeProvider
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import javax.inject.Qualifier
import javax.inject.Singleton

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class ApplicationScope

@Module
@InstallIn(SingletonComponent::class)
object AppModules {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(context, AppDatabase::class.java, "client_tracker.db")
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    fun provideClientDao(db: AppDatabase): ClientDao = db.clientDao()

    @Provides
    fun provideVisitDao(db: AppDatabase): VisitDao = db.visitDao()

    @Provides
    @Singleton
    @ApplicationScope
    fun provideApplicationScope(): CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Provides
    @Singleton
    fun provideTimeProvider(systemTimeProvider: SystemTimeProvider): TimeProvider = systemTimeProvider
}
