package com.wolf.clienttracker.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

data class ClientWithVisits(
    @Embedded val client: ClientEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "clientId",
        entity = VisitEntity::class,
    )
    val visits: List<VisitEntity>,
)

@Dao
interface ClientDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(client: ClientEntity): Long

    @Update
    suspend fun update(client: ClientEntity)

    @Delete
    suspend fun delete(client: ClientEntity)

    @Query("SELECT * FROM clients WHERE id = :id")
    suspend fun getById(id: Long): ClientEntity?

    @Query("SELECT * FROM clients WHERE normalizedPhone = :normalizedPhone")
    suspend fun getByNormalizedPhone(normalizedPhone: String): ClientEntity?

    @Query(
        "SELECT * FROM clients " +
            "WHERE name LIKE '%' || :q || '%' " +
            "OR normalizedPhone LIKE '%' || :q || '%' " +
            "OR displayPhone LIKE '%' || :q || '%' " +
            "ORDER BY name COLLATE NOCASE"
    )
    fun searchClients(q: String): Flow<List<ClientEntity>>

    @Query("SELECT * FROM clients ORDER BY name COLLATE NOCASE")
    fun observeAllClients(): Flow<List<ClientEntity>>

    @Transaction
    @Query(
        "SELECT * FROM clients " +
            "WHERE name LIKE '%' || :q || '%' " +
            "OR normalizedPhone LIKE '%' || :q || '%' " +
            "OR displayPhone LIKE '%' || :q || '%' " +
            "ORDER BY name COLLATE NOCASE"
    )
    fun searchClientsWithVisits(q: String): Flow<List<ClientWithVisits>>

    @Transaction
    @Query("SELECT * FROM clients ORDER BY name COLLATE NOCASE")
    fun observeAllClientsWithVisits(): Flow<List<ClientWithVisits>>

    @Transaction
    @Query("SELECT * FROM clients ORDER BY name COLLATE NOCASE")
    suspend fun getAllClientsWithVisitsOnce(): List<ClientWithVisits>

    @Transaction
    @Query("SELECT * FROM clients WHERE id = :id")
    fun observeClientWithVisits(id: Long): Flow<ClientWithVisits?>
}

@Dao
interface VisitDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(visit: VisitEntity): Long

    @Delete
    suspend fun delete(visit: VisitEntity)

    @Query("SELECT * FROM visits WHERE clientId = :clientId ORDER BY timestampEpochMillis DESC")
    fun observeVisitsForClient(clientId: Long): Flow<List<VisitEntity>>

    @Query("SELECT COUNT(*) FROM visits WHERE clientId = :clientId")
    suspend fun countForClient(clientId: Long): Int

    @Query("SELECT COUNT(*) FROM visits")
    fun observeTotalVisits(): Flow<Int>

    @Query(
        "SELECT COUNT(*) FROM visits WHERE timestampEpochMillis BETWEEN :startMillis AND :endMillis"
    )
    fun observeCountBetween(startMillis: Long, endMillis: Long): Flow<Int>
}
