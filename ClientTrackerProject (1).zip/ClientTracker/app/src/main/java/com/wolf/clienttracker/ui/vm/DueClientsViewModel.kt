package com.wolf.clienttracker.ui.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wolf.clienttracker.domain.usecase.LogVisitUseCase
import com.wolf.clienttracker.domain.usecase.ObserveAllClientsWithVisitsUseCase
import com.wolf.clienttracker.domain.prediction.DueStatus
import com.wolf.clienttracker.domain.service.ClientPredictionService
import com.wolf.clienttracker.domain.time.TimeProvider
import com.wolf.clienttracker.ui.common.UiEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DueClientsViewModel @Inject constructor(
    private val observeAllClientsWithVisits: ObserveAllClientsWithVisitsUseCase,
    private val logVisitUseCase: LogVisitUseCase,
    private val predictionService: ClientPredictionService,
    private val timeProvider: TimeProvider,
) : ViewModel() {

    private val _events = MutableSharedFlow<UiEvent>()
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    data class Row(
        val clientId: Long,
        val name: String,
        val phone: String,
        val lastVisit: String?,
        val nextExpected: String?,
        val expectedIntervalDays: Int,
        val status: DueStatus,
        val sortKey: Long?,
    )

    data class UiState(
        val overdue: List<Row> = emptyList(),
        val dueSoon: List<Row> = emptyList(),
    )

    val state: StateFlow<UiState> = combine(
        observeAllClientsWithVisits(),
        predictionService.settingsFlow,
    ) { clients, settings ->
        val today = timeProvider.todayLocalDate()
        val rows = clients.map { c ->
            val p = predictionService.compute(c, todayOverride = today, settings = settings)
            Row(
                clientId = c.client.id,
                name = c.client.name,
                phone = c.client.displayPhone,
                lastVisit = p.lastVisit?.toString(),
                nextExpected = p.nextExpectedDate?.toString(),
                expectedIntervalDays = p.expectedIntervalDays,
                status = p.status,
                sortKey = p.nextExpectedDate?.toEpochDay(),
            )
        }

        val overdue = rows.filter { it.status == DueStatus.OVERDUE }
            .sortedBy { it.sortKey ?: Long.MAX_VALUE }
        val dueSoon = rows.filter { it.status == DueStatus.DUE_SOON }
            .sortedBy { it.sortKey ?: Long.MAX_VALUE }

        UiState(overdue = overdue, dueSoon = dueSoon)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState())

    fun logVisit(clientId: Long) {
        viewModelScope.launch {
            val res = logVisitUseCase(clientId, timeProvider.nowInstant(), notes = null)
            _events.emit(UiEvent.Message(if (res.isSuccess) "Visit logged." else (res.exceptionOrNull()?.message ?: "Failed")))
        }
    }
}
