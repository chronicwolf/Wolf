package com.wolf.clienttracker.ui.screens

import android.app.TimePickerDialog
import android.net.Uri
import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wolf.clienttracker.ui.common.UiEvent
import com.wolf.clienttracker.ui.vm.SettingsViewModel
import androidx.core.content.ContextCompat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onOpenDiagnostics: () -> Unit,
    vm: SettingsViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsState()
    val ioState by vm.ioState.collectAsState()

    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        vm.events.collect { ev ->
            if (ev is UiEvent.Message) snackbar.showSnackbar(ev.text)
        }
    }

    val context = LocalContext.current

    val exportJsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        uri?.let { vm.exportJson(it) }
    }
    val exportCsvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
        uri?.let { vm.exportCsv(it) }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { vm.import(it) }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted.value = granted
    }
    val permissionGranted = remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= 33) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
            } else true
        )
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Settings") }) },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (ioState.isWorking) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            ioState.lastMessage?.let { Text(it) }
            ioState.lastImportSummary?.let { s ->
                Text("Import summary: clients added=${s.clientsAdded}, duplicates skipped=${s.duplicatesSkipped}, visits added=${s.visitsAdded}, visits skipped=${s.visitsSkipped}")
            }

            OutlinedTextField(
                value = state.globalDefaultIntervalDays.toString(),
                onValueChange = { it.toIntOrNull()?.let(vm::setGlobalDefaultIntervalDays) },
                label = { Text("Global default interval (days)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            OutlinedTextField(
                value = state.dueSoonWindowDays.toString(),
                onValueChange = { it.toIntOrNull()?.let(vm::setDueSoonWindowDays) },
                label = { Text("Due soon window (days)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            OutlinedTextField(
                value = state.intervalsToConsider.toString(),
                onValueChange = { it.toIntOrNull()?.let(vm::setIntervalsToConsider) },
                label = { Text("Intervals to consider (3–10)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("Notifications enabled")
                Switch(checked = state.notificationsEnabled, onCheckedChange = vm::setNotificationsEnabled)
            }

            if (state.notificationsEnabled && Build.VERSION.SDK_INT >= 33 && !permissionGranted.value) {
                AssistChip(
                    onClick = {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    },
                    label = { Text("Grant notification permission") },
                )
            }

            val hour = state.notificationTimeMinutes / 60
            val minute = state.notificationTimeMinutes % 60
            val timeText = String.format("%02d:%02d", hour, minute)

            OutlinedButton(
                onClick = {
                    TimePickerDialog(context, { _, h, m ->
                        vm.setNotificationTimeMinutes(h * 60 + m)
                    }, hour, minute, true).show()
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("Notification time: $timeText")
            }

            OutlinedButton(onClick = vm::sendTestNotificationNow, modifier = Modifier.fillMaxWidth()) {
                Text("Test notification")
            }

            OutlinedButton(onClick = { exportJsonLauncher.launch("client-tracker-export.json") }, modifier = Modifier.fillMaxWidth()) {
                Text("Export JSON")
            }
            OutlinedButton(onClick = { exportCsvLauncher.launch("client-tracker-export.csv") }, modifier = Modifier.fillMaxWidth()) {
                Text("Export CSV")
            }
            OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                Text("Import from file")
            }

            Divider()

            TextButton(onClick = onOpenDiagnostics) { Text("Open Diagnostics") }
        }
    }
}
