package com.wolf.clienttracker.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

@Composable
fun OnboardingScreen(
    onAddFirstClient: () -> Unit,
    onEnableNotifications: () -> Unit,
    onSkip: () -> Unit,
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val permissionGranted = remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= 33) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
            } else true
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted.value = granted
        onEnableNotifications()
        scope.launch {
            snackbarHostState.showSnackbar(if (granted) "Notifications enabled." else "Notifications permission denied.")
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Welcome", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Track clients, log visits, and get notified when clients are due.",
                style = MaterialTheme.typography.bodyLarge,
            )

            Spacer(Modifier.height(8.dp))

            Button(onClick = onAddFirstClient, modifier = Modifier.fillMaxWidth()) {
                Text("Add your first client")
            }

            OutlinedButton(
                onClick = {
                    if (Build.VERSION.SDK_INT >= 33 && !permissionGranted.value) {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        onEnableNotifications()
                        scope.launch { snackbarHostState.showSnackbar("Notifications already enabled.") }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("Enable notifications")
            }

            TextButton(onClick = onSkip, modifier = Modifier.testTag("onboarding_skip")) { Text("Skip") }
        }
    }
}
