package com.wolf.clienttracker

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.rememberNavController
import com.wolf.clienttracker.notifications.NotificationConstants
import com.wolf.clienttracker.ui.nav.AppNavHost
import com.wolf.clienttracker.ui.nav.AppRoute
import com.wolf.clienttracker.ui.screens.OnboardingScreen
import com.wolf.clienttracker.ui.theme.ClientTrackerTheme
import com.wolf.clienttracker.ui.vm.AppStartViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun ClientTrackerRoot() {
    ClientTrackerTheme {
        val navController = rememberNavController()
        val startVm: AppStartViewModel = hiltViewModel()
        val onboardingComplete by startVm.onboardingComplete.collectAsState(initial = false)

        val context = LocalContext.current
        val activity = context as? MainActivity
        val action = activity?.intentActionState?.value
        LaunchedEffect(action) {
            if (action == NotificationConstants.ACTION_OPEN_DUE) {
                // If onboarding isn't complete, navigation happens after onboarding.
                startVm.setPendingOpenDue(true)
                activity?.intent?.action = null
                activity?.intentActionState?.value = null
            }
        }

        if (!onboardingComplete) {
            OnboardingScreen(
                onAddFirstClient = {
                    startVm.completeOnboarding()
                    navController.navigate(AppRoute.AddEditClient.createRoute(null))
                },
                onEnableNotifications = {
                    startVm.requestNotificationsFromOnboarding()
                },
                onSkip = {
                    startVm.completeOnboarding()
                },
            )
        } else {
            AppNavHost(navController = navController)
            val pendingOpenDue by startVm.pendingOpenDue.collectAsState(initial = false)
            LaunchedEffect(pendingOpenDue) {
                if (pendingOpenDue) {
                    navController.navigate(AppRoute.DueClients.route)
                    startVm.setPendingOpenDue(false)
                }
            }
        }
    }
}
