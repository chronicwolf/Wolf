package com.wolf.clienttracker.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wolf.clienttracker.ui.vm.ClientsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientsScreen(
    onOpenClient: (Long) -> Unit,
    onAddClient: () -> Unit,
    vm: ClientsViewModel = hiltViewModel(),
) {
    val query by vm.query.collectAsState()
    val filter by vm.filter.collectAsState()
    val sort by vm.sort.collectAsState()
    val items by vm.items.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Clients") },
                actions = {
                    TextButton(onClick = onAddClient) { Text("Add") }
                }
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = vm::setQuery,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search") },
                singleLine = true,
            )

            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = filter == ClientsViewModel.Filter.ALL, onClick = { vm.setFilter(ClientsViewModel.Filter.ALL) }, label = { Text("All") })
                FilterChip(selected = filter == ClientsViewModel.Filter.DUE_SOON, onClick = { vm.setFilter(ClientsViewModel.Filter.DUE_SOON) }, label = { Text("Due Soon") })
                FilterChip(selected = filter == ClientsViewModel.Filter.OVERDUE, onClick = { vm.setFilter(ClientsViewModel.Filter.OVERDUE) }, label = { Text("Overdue") })
                FilterChip(selected = filter == ClientsViewModel.Filter.NO_VISITS, onClick = { vm.setFilter(ClientsViewModel.Filter.NO_VISITS) }, label = { Text("No Visits") })
            }

            Spacer(Modifier.height(12.dp))

            var sortMenu by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { sortMenu = true }) {
                    Text("Sort: ${if (sort == ClientsViewModel.Sort.NEXT_EXPECTED) "Next expected" else "Name"}")
                }
                DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                    DropdownMenuItem(
                        text = { Text("Next expected") },
                        onClick = { vm.setSort(ClientsViewModel.Sort.NEXT_EXPECTED); sortMenu = false },
                    )
                    DropdownMenuItem(
                        text = { Text("Name") },
                        onClick = { vm.setSort(ClientsViewModel.Sort.NAME); sortMenu = false },
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.clientId }) { item ->
                    ElevatedCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenClient(item.clientId) }
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(item.name, style = MaterialTheme.typography.titleMedium)
                            Text(item.phone)
                            Text("Status: ${item.status}")
                            Text("Last: ${item.lastVisit ?: "-"}")
                            Text("Next: ${item.nextExpected ?: "-"}  (${item.expectedIntervalDays}d)")
                        }
                    }
                }
            }
        }
    }
}
