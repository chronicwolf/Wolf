package com.wolf.clienttracker.domain.service

import com.wolf.clienttracker.data.settings.SettingsRepository
import com.wolf.clienttracker.domain.model.ClientWithVisits
import com.wolf.clienttracker.domain.prediction.DueStatus
import com.wolf.clienttracker.domain.prediction.PredictionEngine
import com.wolf.clienttracker.domain.prediction.PredictionResult
import com.wolf.clienttracker.domain.prediction.PredictionSettings
import com.wolf.clienttracker.domain.time.TimeProvider
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ClientPredictionService @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val timeProvider: TimeProvider,
    private val engine: PredictionEngine,
) {

    val settingsFlow: Flow<PredictionSettings> = combine(
        settingsRepository.globalDefaultIntervalDays,
        settingsRepository.dueSoonWindowDays,
        settingsRepository.intervalsToConsider,
    ) { globalDefault, dueSoon, n ->
        PredictionSettings(
            globalDefaultIntervalDays = globalDefault,
            dueSoonWindowDays = dueSoon,
            intervalsToConsider = n,
        )
    }

    fun compute(
        clientWithVisits: ClientWithVisits,
        todayOverride: java.time.LocalDate? = null,
        settings: PredictionSettings,
    ): PredictionResult {
        val instants: List<Instant> = clientWithVisits.visits.map { it.timestamp }
        val today = todayOverride ?: timeProvider.todayLocalDate()
        return engine.predict(
            visitInstants = instants,
            zoneId = timeProvider.zoneId(),
            today = today,
            settings = settings,
        )
    }

    data class DashboardCounts(
        val overdue: Int,
        val dueSoon: Int,
        val noVisits: Int,
    )

    fun dashboardCounts(items: List<PredictionResult>): DashboardCounts {
        var overdue = 0
        var dueSoon = 0
        var noVisits = 0
        for (p in items) {
            when (p.status) {
                DueStatus.OVERDUE -> overdue++
                DueStatus.DUE_SOON -> dueSoon++
                DueStatus.NO_VISITS -> noVisits++
                else -> Unit
            }
        }
        return DashboardCounts(overdue = overdue, dueSoon = dueSoon, noVisits = noVisits)
    }
}
