package com.wolf.clienttracker.domain.prediction

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import kotlin.math.max
import kotlin.math.roundToInt
import javax.inject.Inject

class PredictionEngine @Inject constructor() {

    fun predict(
        visitInstants: List<Instant>,
        zoneId: ZoneId,
        today: LocalDate,
        settings: PredictionSettings,
    ): PredictionResult {
        val localDates = visitInstants
            .map { it.atZone(zoneId).toLocalDate() }
            .distinct()
            .sorted()

        if (localDates.isEmpty()) {
            return PredictionResult(
                lastVisit = null,
                gapsUsed = emptyList(),
                expectedIntervalDays = settings.globalDefaultIntervalDays,
                nextExpectedDate = null,
                status = DueStatus.NO_VISITS,
                likelyWindow = null,
                hasEnoughHistoryForWindow = false,
            )
        }

        val gapsAll = computeGaps(localDates)
        val n = settings.intervalsToConsider.coerceIn(3, 10)
        val gapsUsed = gapsAll.takeLast(n)

        val expectedInterval = when (gapsAll.size) {
            0 -> settings.globalDefaultIntervalDays
            1 -> gapsAll.first()
            else -> medianInt(gapsUsed)
        }.coerceAtLeast(1)

        val lastVisit = localDates.last()
        val nextExpected = lastVisit.plusDays(expectedInterval.toLong())

        val status = when {
            localDates.isEmpty() -> DueStatus.NO_VISITS
            today.isAfter(nextExpected) -> DueStatus.OVERDUE
            !today.isBefore(nextExpected.minusDays(settings.dueSoonWindowDays.toLong())) && !today.isAfter(nextExpected) -> DueStatus.DUE_SOON
            else -> DueStatus.OK
        }

        val hasEnoughForWindow = gapsAll.size >= 3
        val likelyWindow = if (hasEnoughForWindow) {
            val variabilityDays = max(1, (iqrInt(gapsUsed) / 2.0).roundToInt())
            LikelyWindow(
                start = nextExpected.minusDays(variabilityDays.toLong()),
                end = nextExpected.plusDays(variabilityDays.toLong()),
                variabilityDays = variabilityDays,
            )
        } else {
            null
        }

        return PredictionResult(
            lastVisit = lastVisit,
            gapsUsed = gapsUsed,
            expectedIntervalDays = expectedInterval,
            nextExpectedDate = nextExpected,
            status = status,
            likelyWindow = likelyWindow,
            hasEnoughHistoryForWindow = hasEnoughForWindow,
        )
    }

    private fun computeGaps(sortedDistinctDates: List<LocalDate>): List<Int> {
        if (sortedDistinctDates.size < 2) return emptyList()
        val gaps = ArrayList<Int>(sortedDistinctDates.size - 1)
        for (i in 1 until sortedDistinctDates.size) {
            val prev = sortedDistinctDates[i - 1]
            val curr = sortedDistinctDates[i]
            val days = ChronoUnit.DAYS.between(prev, curr).toInt()
            gaps.add(max(1, days))
        }
        return gaps
    }

    fun medianInt(values: List<Int>): Int {
        require(values.isNotEmpty())
        val sorted = values.sorted()
        val mid = sorted.size / 2
        return if (sorted.size % 2 == 1) {
            sorted[mid]
        } else {
            ((sorted[mid - 1] + sorted[mid]) / 2.0).roundToInt()
        }
    }

    fun iqrInt(values: List<Int>): Int {
        require(values.isNotEmpty())
        val sorted = values.sorted()
        if (sorted.size < 4) {
            // small sample; treat iqr conservatively
            return 0
        }

        val mid = sorted.size / 2
        val lower = if (sorted.size % 2 == 0) sorted.subList(0, mid) else sorted.subList(0, mid)
        val upper = if (sorted.size % 2 == 0) sorted.subList(mid, sorted.size) else sorted.subList(mid + 1, sorted.size)

        val q1 = medianInt(lower)
        val q3 = medianInt(upper)
        return (q3 - q1).coerceAtLeast(0)
    }
}
