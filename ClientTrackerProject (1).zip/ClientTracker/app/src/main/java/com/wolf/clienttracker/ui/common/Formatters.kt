package com.wolf.clienttracker.ui.common

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val visitFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

fun formatInstantLocal(instant: Instant, zoneId: ZoneId): String {
    return instant.atZone(zoneId).format(visitFormatter)
}
