package com.wolf.clienttracker.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wolf.clienttracker.BuildConfig
import com.wolf.clienttracker.ui.vm.DiagnosticsViewModel
import java.time.LocalDate
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnosticsScreen(
    onBack: () -> Unit,
    vm: DiagnosticsViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Diagnostics") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Device time zone: ${state.zoneId}")
            Text("Today (local date used): ${state.today}")
            Text("Current local time: ${state.nowLocal}")
            Text("Notification permission: ${state.notificationPermission}")
            Text("Notifications enabled (setting): ${state.notificationsEnabled}")
            Text("Next scheduled notification (estimate): ${state.nextScheduledEstimate}")
            Text("Last WorkManager run: ${state.lastWorkerRun ?: "-"}")
            Text("Last notification sent: ${state.lastNotificationSent ?: "-"}")
            Text("Simulated today (debug): ${state.simulatedToday}")

            Divider()

            Text(
                "Calendar basis: Visits stored as Instant (UTC) and converted to LocalDate in this timezone for predictions.",
                style = MaterialTheme.typography.bodyMedium,
            )

            Spacer(Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = vm::runDueCheckNow) { Text("Run due-check now") }
                OutlinedButton(onClick = vm::sendTestNotificationNow) { Text("Send test notification now") }
            }

            if (BuildConfig.DEBUG) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(
                        onClick = {
                            val now = LocalDate.now()
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val picked = LocalDate.of(y, m + 1, d)
                                    vm.setSimulatedTodayOrNull(picked.toEpochDay())
                                },
                                now.year,
                                now.monthValue - 1,
                                now.dayOfMonth,
                            ).show()
                        }
                    ) { Text("Set simulated today") }

                    TextButton(onClick = { vm.setSimulatedTodayOrNull(-1L) }) { Text("Clear") }
                }
            }
        }
    }
}
