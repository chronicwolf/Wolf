package com.wolf.clienttracker.ui.common

sealed interface UiEvent {
    data class Message(val text: String) : UiEvent
}
