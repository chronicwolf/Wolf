package com.wolf.clienttracker.ui.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wolf.clienttracker.data.settings.SettingsRepository
import com.wolf.clienttracker.worker.NotificationScheduler
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AppStartViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val scheduler: NotificationScheduler,
) : ViewModel() {

    val onboardingComplete = settingsRepository.onboardingComplete

    private val _pendingOpenDue = MutableStateFlow(false)
    val pendingOpenDue: StateFlow<Boolean> = _pendingOpenDue

    init {
        viewModelScope.launch {
            if (settingsRepository.onboardingComplete.first()) {
                scheduler.scheduleDaily()
            }
        }
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            settingsRepository.setOnboardingComplete(true)
            scheduler.scheduleDaily()
        }
    }

    fun requestNotificationsFromOnboarding() {
        // Permission request is handled in the screen via launcher.
        // Here we just schedule daily work based on settings.
        viewModelScope.launch { scheduler.scheduleDaily() }
    }

    fun setPendingOpenDue(value: Boolean) {
        _pendingOpenDue.value = value
    }
}
