package com.wolf.clienttracker.domain.prediction

import java.time.LocalDate

enum class DueStatus {
    NO_VISITS,
    OVERDUE,
    DUE_SOON,
    OK,
}

data class PredictionSettings(
    val globalDefaultIntervalDays: Int = 21,
    val dueSoonWindowDays: Int = 3,
    val intervalsToConsider: Int = 5,
)

data class LikelyWindow(
    val start: LocalDate,
    val end: LocalDate,
    val variabilityDays: Int,
)

data class PredictionResult(
    val lastVisit: LocalDate?,
    val gapsUsed: List<Int>,
    val expectedIntervalDays: Int,
    val nextExpectedDate: LocalDate?,
    val status: DueStatus,
    val likelyWindow: LikelyWindow?,
    val hasEnoughHistoryForWindow: Boolean,
)
