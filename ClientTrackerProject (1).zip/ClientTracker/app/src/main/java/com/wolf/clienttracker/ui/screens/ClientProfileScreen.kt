package com.wolf.clienttracker.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wolf.clienttracker.domain.model.Visit
import com.wolf.clienttracker.domain.prediction.DueStatus
import com.wolf.clienttracker.ui.common.formatInstantLocal
import com.wolf.clienttracker.ui.common.UiEvent
import com.wolf.clienttracker.ui.vm.ClientProfileViewModel
import java.time.ZoneId

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientProfileScreen(
    clientId: Long,
    onEditClient: () -> Unit,
    onBack: () -> Unit,
    vm: ClientProfileViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    val context = LocalContext.current

    LaunchedEffect(Unit) {
        vm.events.collect { ev ->
            if (ev is UiEvent.Message) snackbar.showSnackbar(ev.text)
        }
    }

    var showDeleteClient by remember { mutableStateOf(false) }
    var showLogDialog by remember { mutableStateOf(false) }
    var logNotes by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.clientName.ifBlank { "Client" }) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                },
                actions = {
                    IconButton(onClick = onEditClient) { Icon(Icons.Filled.Edit, contentDescription = "Edit") }
                    IconButton(onClick = { showDeleteClient = true }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showLogDialog = true }, modifier = Modifier.testTag("log_visit_button")) {
                Icon(Icons.Filled.Add, contentDescription = "Log Visit")
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        if (state.isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                ElevatedCard {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Phone", style = MaterialTheme.typography.labelLarge)
                                Text(state.phone, style = MaterialTheme.typography.bodyLarge)
                            }
                            IconButton(onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("phone", state.phone))
                            }) {
                                Icon(Icons.Filled.ContentCopy, contentDescription = "Copy")
                            }
                        }
                        state.notes?.takeIf { it.isNotBlank() }?.let {
                            Text("Notes", style = MaterialTheme.typography.labelLarge)
                            Text(it)
                        }
                    }
                }
            }

            item {
                PredictionBlock(prediction = state.prediction)
            }

            item {
                Text("Visit history", style = MaterialTheme.typography.titleMedium)
            }

            items(state.visitHistory, key = { it.id }) { visit ->
                VisitRow(visit = visit, zoneId = ZoneId.systemDefault(), onDelete = { vm.deleteVisit(visit) })
            }

            if (state.visitHistory.isEmpty()) {
                item {
                    Text("No visits yet.")
                }
            }
        }
    }

    if (showDeleteClient) {
        AlertDialog(
            onDismissRequest = { showDeleteClient = false },
            title = { Text("Delete client?") },
            text = { Text("This will delete the client and all visit history.") },
            confirmButton = {
                TextButton(onClick = { showDeleteClient = false; vm.deleteClient(); onBack() }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { showDeleteClient = false }) { Text("Cancel") } },
        )
    }

    if (showLogDialog) {
        AlertDialog(
            onDismissRequest = { showLogDialog = false },
            title = { Text("Log visit") },
            text = {
                OutlinedTextField(
                    value = logNotes,
                    onValueChange = { logNotes = it },
                    label = { Text("Notes / service (optional)") },
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showLogDialog = false
                    vm.logVisit(logNotes.trim().ifBlank { null })
                    logNotes = ""
                }) { Text("Log") }
            },
            dismissButton = {
                TextButton(onClick = { showLogDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun PredictionBlock(prediction: com.wolf.clienttracker.domain.prediction.PredictionResult?) {
    ElevatedCard {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Prediction", style = MaterialTheme.typography.titleMedium)

            if (prediction == null) {
                Text("Loading...")
                return@Column
            }

            Text("Last visit: ${prediction.lastVisit?.toString() ?: "-"}")
            Text("Gaps used: ${prediction.gapsUsed.joinToString(prefix = "[", postfix = "]") { it.toString() }} days")
            Text("Expected interval: ${prediction.expectedIntervalDays} days")
            Text(
                "Next expected visit: ${prediction.nextExpectedDate?.toString() ?: "-"}",
                modifier = Modifier.testTag("prediction_next_expected"),
            )

            if (prediction.hasEnoughHistoryForWindow && prediction.likelyWindow != null) {
                Text("Likely window: ${prediction.likelyWindow.start} to ${prediction.likelyWindow.end} (±${prediction.likelyWindow.variabilityDays}d)")
            } else {
                Text("Not enough history for window.")
            }

            Text(
                "Status: ${when (prediction.status) {
                    DueStatus.OK -> "OK"
                    DueStatus.DUE_SOON -> "Due Soon"
                    DueStatus.OVERDUE -> "Overdue"
                    DueStatus.NO_VISITS -> "No Visits"
                }}",
                style = MaterialTheme.typography.titleSmall,
            )
        }
    }
}

@Composable
private fun VisitRow(visit: Visit, zoneId: ZoneId, onDelete: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }

    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f)) {
                Text(formatInstantLocal(visit.timestamp, zoneId), style = MaterialTheme.typography.bodyMedium)
                visit.notes?.takeIf { it.isNotBlank() }?.let { Text(it) }
            }
            IconButton(onClick = { confirm = true }) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete visit")
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Delete visit?") },
            confirmButton = { TextButton(onClick = { confirm = false; onDelete() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        )
    }
}
