package com.wolf.clienttracker.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import com.wolf.clienttracker.data.settings.SettingsRepository
import com.wolf.clienttracker.ui.common.UiEvent
import com.wolf.clienttracker.ui.vm.HomeViewModel
import dagger.hilt.android.EntryPointAccessors
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenClient: (Long) -> Unit,
    onAddClient: () -> Unit,
    onOpenDue: () -> Unit,
    vm: HomeViewModel = hiltViewModel(),
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val query by vm.query.collectAsState()
    val dashboard by vm.dashboard.collectAsState()
    val results by vm.searchResults.collectAsState()

    val context = LocalContext.current

    // Notification permission banner check
    val repo = remember {
        EntryPointAccessors.fromApplication(
            context,
            SettingsRepoEntryPoint::class.java
        ).settingsRepository()
    }
    val notificationsEnabled by repo.notificationsEnabled.collectAsState(initial = true)

    val permissionGranted = remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= 33) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
            } else true
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted.value = granted
        scope.launch {
            snackbarHostState.showSnackbar(if (granted) "Notifications enabled." else "Notifications permission denied.")
        }
    }

    LaunchedEffect(Unit) {
        vm.events.collect { event ->
            when (event) {
                is UiEvent.Message -> snackbarHostState.showSnackbar(event.text)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Client Tracker") },
                actions = {
                    TextButton(onClick = onAddClient) { Text("Add") }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
        ) {
            if (!notificationsEnabled || !permissionGranted.value) {
                AssistChip(
                    onClick = {
                        if (Build.VERSION.SDK_INT >= 33 && !permissionGranted.value) {
                            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    },
                    label = { Text("Notifications disabled") },
                )
                Spacer(Modifier.height(8.dp))
            }

            OutlinedTextField(
                value = query,
                onValueChange = vm::setQuery,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_search"),
                placeholder = { Text("Search clients by name or phone") },
                singleLine = true,
            )

            Spacer(Modifier.height(12.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(title = "Overdue", value = dashboard.overdueCount.toString(), onClick = onOpenDue)
                StatCard(title = "Due soon", value = dashboard.dueSoonCount.toString(), onClick = onOpenDue)
                StatCard(title = "Logged today", value = dashboard.loggedTodayCount.toString(), onClick = {})
            }

            Spacer(Modifier.height(16.dp))

            Text("Quick Log", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(results, key = { it.clientId }) { item ->
                    ElevatedCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenClient(item.clientId) }
                            .testTag("client_row_${item.clientId}"),
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(item.name, style = MaterialTheme.typography.titleMedium)
                                Text(item.phone, style = MaterialTheme.typography.bodyMedium)
                                Text("Status: ${item.status}")
                                item.nextExpected?.let { Text("Next expected: $it") }
                            }
                            TextButton(
                                onClick = { vm.logVisitNow(item.clientId) },
                                modifier = Modifier.testTag("log_visit_${item.clientId}"),
                            ) { Text("Log Visit Now") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, onClick: () -> Unit) {
    ElevatedCard(modifier = Modifier.weight(1f).clickable { onClick() }) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(value, style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@dagger.hilt.EntryPoint
@dagger.hilt.InstallIn(dagger.hilt.components.SingletonComponent::class)
interface SettingsRepoEntryPoint {
    fun settingsRepository(): SettingsRepository
}
