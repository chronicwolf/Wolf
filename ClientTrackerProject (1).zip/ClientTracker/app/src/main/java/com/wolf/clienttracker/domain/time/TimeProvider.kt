package com.wolf.clienttracker.domain.time

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

interface TimeProvider {
    fun nowInstant(): Instant
    fun todayLocalDate(): LocalDate
    fun zoneId(): ZoneId
}
