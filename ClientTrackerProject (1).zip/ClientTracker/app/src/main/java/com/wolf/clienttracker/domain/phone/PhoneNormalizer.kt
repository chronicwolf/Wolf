package com.wolf.clienttracker.domain.phone

/**
 * Phone normalization rules:
 * - Keep digits and a single leading '+' if present.
 * - Strip spaces, hyphens, parentheses, dots, and any other non-digit characters.
 * - Store displayPhone (lightly cleaned) and normalizedPhone (for uniqueness).
 */
object PhoneNormalizer {

    data class Result(
        val displayPhone: String,
        val normalizedPhone: String,
    )

    fun normalize(raw: String): Result? {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return null

        val hasLeadingPlus = trimmed.firstOrNull { !it.isWhitespace() } == '+'
        val digits = StringBuilder()
        for (c in trimmed) {
            if (c.isDigit()) digits.append(c)
        }
        if (digits.isEmpty()) return null

        val normalized = (if (hasLeadingPlus) "+" else "") + digits.toString()
        val display = normalized // lightly cleaned

        return Result(displayPhone = display, normalizedPhone = normalized)
    }
}
