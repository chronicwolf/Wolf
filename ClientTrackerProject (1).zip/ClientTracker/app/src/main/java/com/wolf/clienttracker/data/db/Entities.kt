package com.wolf.clienttracker.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "clients",
    indices = [Index(value = ["normalizedPhone"], unique = true)],
)
data class ClientEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val normalizedPhone: String,
    val displayPhone: String,
    val notes: String? = null,
    @ColumnInfo(name = "createdAtEpochMillis") val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "visits",
    foreignKeys = [
        ForeignKey(
            entity = ClientEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [
        Index(value = ["clientId"]),
        Index(value = ["clientId", "timestampEpochMillis"], unique = true),
    ],
)
data class VisitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long,
    @ColumnInfo(name = "timestampEpochMillis") val timestampEpochMillis: Long,
    val notes: String? = null,
)
