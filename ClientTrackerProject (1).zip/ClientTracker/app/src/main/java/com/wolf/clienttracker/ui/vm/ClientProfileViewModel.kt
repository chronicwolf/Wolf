package com.wolf.clienttracker.ui.vm

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wolf.clienttracker.domain.usecase.DeleteClientUseCase
import com.wolf.clienttracker.domain.usecase.DeleteVisitUseCase
import com.wolf.clienttracker.domain.usecase.LogVisitUseCase
import com.wolf.clienttracker.domain.usecase.ObserveClientWithVisitsUseCase
import com.wolf.clienttracker.domain.model.Visit
import com.wolf.clienttracker.domain.prediction.PredictionResult
import com.wolf.clienttracker.domain.service.ClientPredictionService
import com.wolf.clienttracker.domain.time.TimeProvider
import com.wolf.clienttracker.ui.common.UiEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Instant
import javax.inject.Inject

@HiltViewModel
class ClientProfileViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val observeClientWithVisits: ObserveClientWithVisitsUseCase,
    private val logVisitUseCase: LogVisitUseCase,
    private val deleteVisitUseCase: DeleteVisitUseCase,
    private val deleteClientUseCase: DeleteClientUseCase,
    private val predictionService: ClientPredictionService,
    private val timeProvider: TimeProvider,
) : ViewModel() {

    private val clientId: Long = savedStateHandle.get<Long>("clientId") ?: 0L

    private val _events = MutableSharedFlow<UiEvent>()
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    data class UiState(
        val isLoading: Boolean = true,
        val clientName: String = "",
        val phone: String = "",
        val notes: String? = null,
        val prediction: PredictionResult? = null,
        val visitHistory: List<Visit> = emptyList(),
    )

    val state: StateFlow<UiState> = combine(
        observeClientWithVisits(clientId),
        predictionService.settingsFlow,
    ) { c, settings ->
        if (c == null) {
            UiState(isLoading = false)
        } else {
            val today = timeProvider.todayLocalDate()
            val prediction = predictionService.compute(c, todayOverride = today, settings = settings)
            UiState(
                isLoading = false,
                clientName = c.client.name,
                phone = c.client.displayPhone,
                notes = c.client.notes,
                prediction = prediction,
                visitHistory = c.visits.sortedByDescending { it.timestamp },
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState())

    fun logVisit(notes: String?) {
        viewModelScope.launch {
            val res = logVisitUseCase(clientId, timeProvider.nowInstant(), notes)
            if (res.isSuccess) _events.emit(UiEvent.Message("Visit logged."))
            else _events.emit(UiEvent.Message(res.exceptionOrNull()?.message ?: "Failed"))
        }
    }

    fun deleteVisit(visit: Visit) {
        viewModelScope.launch {
            deleteVisitUseCase(visit)
            _events.emit(UiEvent.Message("Visit deleted."))
        }
    }

    fun deleteClient() {
        viewModelScope.launch {
            val res = deleteClientUseCase(clientId)
            if (res.isSuccess) _events.emit(UiEvent.Message("Client deleted."))
            else _events.emit(UiEvent.Message(res.exceptionOrNull()?.message ?: "Failed"))
        }
    }
}
