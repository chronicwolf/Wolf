package com.wolf.clienttracker.data.repo

import com.wolf.clienttracker.data.db.ClientDao
import com.wolf.clienttracker.data.db.ClientEntity
import com.wolf.clienttracker.data.db.ClientWithVisits as DbClientWithVisits
import com.wolf.clienttracker.data.db.VisitDao
import com.wolf.clienttracker.data.db.VisitEntity
import com.wolf.clienttracker.domain.model.Client
import com.wolf.clienttracker.domain.model.ClientWithVisits
import com.wolf.clienttracker.domain.model.Visit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ClientRepository @Inject constructor(
    private val clientDao: ClientDao,
    private val visitDao: VisitDao,
) {

    fun observeAllClientsWithVisits(): Flow<List<ClientWithVisits>> {
        return clientDao.observeAllClientsWithVisits().map { list -> list.map { it.toDomain() } }
    }

    fun searchClientsWithVisits(query: String): Flow<List<ClientWithVisits>> {
        val q = query.trim()
        return if (q.isBlank()) {
            observeAllClientsWithVisits()
        } else {
            clientDao.searchClientsWithVisits(q).map { list -> list.map { it.toDomain() } }
        }
    }

    fun observeClientWithVisits(clientId: Long): Flow<ClientWithVisits?> {
        return clientDao.observeClientWithVisits(clientId).map { it?.toDomain() }
    }

    suspend fun getAllClientsWithVisitsOnce(): List<ClientWithVisits> {
        return clientDao.getAllClientsWithVisitsOnce().map { it.toDomain() }
    }

    suspend fun addClient(
        name: String,
        normalizedPhone: String,
        displayPhone: String,
        notes: String?,
        createdAt: Instant,
    ): Result<Long> {
        val id = clientDao.insert(
            ClientEntity(
                name = name,
                normalizedPhone = normalizedPhone,
                displayPhone = displayPhone,
                notes = notes,
                createdAtEpochMillis = createdAt.toEpochMilli(),
            )
        )
        return if (id == -1L) {
            Result.failure(IllegalStateException("A client with this phone already exists."))
        } else {
            Result.success(id)
        }
    }

    suspend fun updateClient(
        id: Long,
        name: String,
        normalizedPhone: String,
        displayPhone: String,
        notes: String?,
    ): Result<Unit> {
        val existing = clientDao.getById(id) ?: return Result.failure(IllegalStateException("Client not found"))

        // If phone changed, ensure uniqueness.
        if (existing.normalizedPhone != normalizedPhone) {
            val byPhone = clientDao.getByNormalizedPhone(normalizedPhone)
            if (byPhone != null) return Result.failure(IllegalStateException("Another client already has this phone."))
        }

        clientDao.update(
            existing.copy(
                name = name,
                normalizedPhone = normalizedPhone,
                displayPhone = displayPhone,
                notes = notes,
            )
        )
        return Result.success(Unit)
    }

    suspend fun deleteClient(clientId: Long): Result<Unit> {
        val existing = clientDao.getById(clientId) ?: return Result.failure(IllegalStateException("Client not found"))
        clientDao.delete(existing)
        return Result.success(Unit)
    }

    suspend fun logVisit(clientId: Long, timestamp: Instant, notes: String?): Result<Long> {
        val client = clientDao.getById(clientId) ?: return Result.failure(IllegalStateException("Client not found"))
        val id = visitDao.insert(
            VisitEntity(
                clientId = client.id,
                timestampEpochMillis = timestamp.toEpochMilli(),
                notes = notes,
            )
        )
        return if (id == -1L) {
            Result.failure(IllegalStateException("Duplicate visit timestamp"))
        } else {
            Result.success(id)
        }
    }

    suspend fun findClientByNormalizedPhone(normalizedPhone: String): Client? {
        return clientDao.getByNormalizedPhone(normalizedPhone)?.let {
            Client(
                id = it.id,
                name = it.name,
                normalizedPhone = it.normalizedPhone,
                displayPhone = it.displayPhone,
                notes = it.notes,
                createdAt = Instant.ofEpochMilli(it.createdAtEpochMillis),
            )
        }
    }

    suspend fun importVisit(clientId: Long, timestamp: Instant, notes: String?): Boolean {
        val id = visitDao.insert(
            VisitEntity(
                clientId = clientId,
                timestampEpochMillis = timestamp.toEpochMilli(),
                notes = notes,
            )
        )
        return id != -1L
    }

    suspend fun deleteVisit(visit: Visit): Result<Unit> {
        visitDao.delete(
            VisitEntity(
                id = visit.id,
                clientId = visit.clientId,
                timestampEpochMillis = visit.timestamp.toEpochMilli(),
                notes = visit.notes,
            )
        )
        return Result.success(Unit)
    }

    private fun DbClientWithVisits.toDomain(): ClientWithVisits {
        val clientDomain = Client(
            id = client.id,
            name = client.name,
            normalizedPhone = client.normalizedPhone,
            displayPhone = client.displayPhone,
            notes = client.notes,
            createdAt = Instant.ofEpochMilli(client.createdAtEpochMillis),
        )
        val visitsDomain = visits.map {
            Visit(
                id = it.id,
                clientId = it.clientId,
                timestamp = Instant.ofEpochMilli(it.timestampEpochMillis),
                notes = it.notes,
            )
        }.sortedByDescending { it.timestamp }

        return ClientWithVisits(client = clientDomain, visits = visitsDomain)
    }
}
