package com.wolf.clienttracker.domain.usecase

import com.wolf.clienttracker.data.repo.ClientRepository
import com.wolf.clienttracker.domain.model.ClientWithVisits
import com.wolf.clienttracker.domain.model.Visit
import kotlinx.coroutines.flow.Flow
import java.time.Instant
import javax.inject.Inject

class ObserveAllClientsWithVisitsUseCase @Inject constructor(
    private val repo: ClientRepository,
) {
    operator fun invoke(): Flow<List<ClientWithVisits>> = repo.observeAllClientsWithVisits()
}

class SearchClientsWithVisitsUseCase @Inject constructor(
    private val repo: ClientRepository,
) {
    operator fun invoke(query: String): Flow<List<ClientWithVisits>> = repo.searchClientsWithVisits(query)
}

class ObserveClientWithVisitsUseCase @Inject constructor(
    private val repo: ClientRepository,
) {
    operator fun invoke(clientId: Long): Flow<ClientWithVisits?> = repo.observeClientWithVisits(clientId)
}

class AddClientUseCase @Inject constructor(
    private val repo: ClientRepository,
) {
    suspend operator fun invoke(
        name: String,
        normalizedPhone: String,
        displayPhone: String,
        notes: String?,
        createdAt: Instant,
    ): Result<Long> = repo.addClient(name, normalizedPhone, displayPhone, notes, createdAt)
}

class UpdateClientUseCase @Inject constructor(
    private val repo: ClientRepository,
) {
    suspend operator fun invoke(
        id: Long,
        name: String,
        normalizedPhone: String,
        displayPhone: String,
        notes: String?,
    ): Result<Unit> = repo.updateClient(id, name, normalizedPhone, displayPhone, notes)
}

class DeleteClientUseCase @Inject constructor(
    private val repo: ClientRepository,
) {
    suspend operator fun invoke(id: Long): Result<Unit> = repo.deleteClient(id)
}

class LogVisitUseCase @Inject constructor(
    private val repo: ClientRepository,
) {
    suspend operator fun invoke(clientId: Long, timestamp: Instant, notes: String?): Result<Long> = repo.logVisit(clientId, timestamp, notes)
}

class DeleteVisitUseCase @Inject constructor(
    private val repo: ClientRepository,
) {
    suspend operator fun invoke(visit: Visit) = repo.deleteVisit(visit)
}

class GetAllClientsWithVisitsOnceUseCase @Inject constructor(
    private val repo: ClientRepository,
) {
    suspend operator fun invoke(): List<ClientWithVisits> = repo.getAllClientsWithVisitsOnce()
}
