package com.wolf.clienttracker.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [ClientEntity::class, VisitEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clientDao(): ClientDao
    abstract fun visitDao(): VisitDao
}
