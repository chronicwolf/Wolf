package com.wolf.clienttracker.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wolf.clienttracker.ui.common.UiEvent
import com.wolf.clienttracker.ui.vm.DueClientsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DueClientsScreen(
    onOpenClient: (Long) -> Unit,
    vm: DueClientsViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        vm.events.collect { ev ->
            if (ev is UiEvent.Message) snackbar.showSnackbar(ev.text)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Due Clients") })
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Text("Overdue", style = MaterialTheme.typography.titleMedium)
            }
            items(state.overdue, key = { "o_${it.clientId}" }) { row ->
                DueRow(row, onOpenClient = onOpenClient, onLog = { vm.logVisit(row.clientId) })
            }
            if (state.overdue.isEmpty()) {
                item { Text("None") }
            }

            item { Spacer(Modifier.height(12.dp)) }

            item {
                Text("Due soon", style = MaterialTheme.typography.titleMedium)
            }
            items(state.dueSoon, key = { "d_${it.clientId}" }) { row ->
                DueRow(row, onOpenClient = onOpenClient, onLog = { vm.logVisit(row.clientId) })
            }
            if (state.dueSoon.isEmpty()) {
                item { Text("None") }
            }
        }
    }
}

@Composable
private fun DueRow(
    row: DueClientsViewModel.Row,
    onOpenClient: (Long) -> Unit,
    onLog: () -> Unit,
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth().clickable { onOpenClient(row.clientId) }) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(row.name, style = MaterialTheme.typography.titleMedium)
            Text(row.phone)
            Text("Last visit: ${row.lastVisit ?: "-"}")
            Text("Next expected: ${row.nextExpected ?: "-"} (${row.expectedIntervalDays}d)")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onLog) { Text("Log Visit") }
            }
        }
    }
}
