package com.wolf.clienttracker.ui.nav

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import com.wolf.clienttracker.ui.screens.*

private data class BottomItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun AppNavHost(navController: NavHostController) {
    val items = listOf(
        BottomItem(AppRoute.Home.route, "Home", Icons.Filled.Home),
        BottomItem(AppRoute.Clients.route, "Clients", Icons.Filled.People),
        BottomItem(AppRoute.Settings.route, "Settings", Icons.Filled.Settings),
    )

    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val showBottom = currentRoute in items.map { it.route }

    Scaffold(
        bottomBar = {
            if (showBottom) {
                NavigationBar {
                    items.forEach { item ->
                        val selected = currentRoute == item.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(AppRoute.Home.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = AppRoute.Home.route,
            modifier = Modifier.padding(padding),
        ) {
            composable(AppRoute.Home.route) {
                HomeScreen(
                    onOpenClient = { navController.navigate(AppRoute.ClientProfile.createRoute(it)) },
                    onAddClient = { navController.navigate(AppRoute.AddEditClient.createRoute(null)) },
                    onOpenDue = { navController.navigate(AppRoute.DueClients.route) },
                )
            }
            composable(AppRoute.Clients.route) {
                ClientsScreen(
                    onOpenClient = { navController.navigate(AppRoute.ClientProfile.createRoute(it)) },
                    onAddClient = { navController.navigate(AppRoute.AddEditClient.createRoute(null)) },
                )
            }
            composable(AppRoute.Settings.route) {
                SettingsScreen(
                    onOpenDiagnostics = { navController.navigate("diagnostics") },
                )
            }
            composable(AppRoute.DueClients.route) {
                DueClientsScreen(
                    onOpenClient = { navController.navigate(AppRoute.ClientProfile.createRoute(it)) },
                )
            }
            composable(
                route = AppRoute.ClientProfile.route,
                arguments = listOf(navArgument(AppRoute.ClientProfile.ARG_ID) { type = NavType.LongType }),
            ) { entry ->
                val id = entry.arguments?.getLong(AppRoute.ClientProfile.ARG_ID) ?: 0L
                ClientProfileScreen(
                    clientId = id,
                    onEditClient = { navController.navigate(AppRoute.AddEditClient.createRoute(id)) },
                    onBack = { navController.popBackStack() },
                )
            }
            composable(
                route = AppRoute.AddEditClient.route,
                arguments = listOf(navArgument(AppRoute.AddEditClient.ARG_ID) {
                    type = NavType.LongType
                    nullable = true
                    defaultValue = -1L
                }),
            ) { entry ->
                val raw = entry.arguments?.getLong(AppRoute.AddEditClient.ARG_ID) ?: -1L
                val id = raw.takeIf { it > 0 }
                AddEditClientScreen(
                    clientId = id,
                    onDone = { newId ->
                        navController.navigate(AppRoute.ClientProfile.createRoute(newId)) {
                            popUpTo(AppRoute.Home.route)
                        }
                    },
                    onCancel = { navController.popBackStack() },
                )
            }

            composable("diagnostics") {
                DiagnosticsScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
