package com.wolf.clienttracker.notifications

object NotificationConstants {
    const val CHANNEL_ID = "clients_due"
    const val CHANNEL_NAME = "Clients Due"
    const val CHANNEL_DESC = "Daily reminder about clients who are due or overdue"

    const val UNIQUE_WORK_NAME = "daily_due_check"

    const val ACTION_OPEN_DUE = "com.wolf.clienttracker.action.OPEN_DUE"
}
