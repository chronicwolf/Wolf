package com.wolf.clienttracker.ui.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wolf.clienttracker.domain.usecase.SearchClientsWithVisitsUseCase
import com.wolf.clienttracker.domain.prediction.DueStatus
import com.wolf.clienttracker.domain.service.ClientPredictionService
import com.wolf.clienttracker.domain.time.TimeProvider
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class ClientsViewModel @Inject constructor(
    private val searchClientsWithVisits: SearchClientsWithVisitsUseCase,
    private val predictionService: ClientPredictionService,
    private val timeProvider: TimeProvider,
) : ViewModel() {

    enum class Filter { ALL, DUE_SOON, OVERDUE, NO_VISITS }
    enum class Sort { NEXT_EXPECTED, NAME }

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query

    private val _filter = MutableStateFlow(Filter.ALL)
    val filter: StateFlow<Filter> = _filter

    private val _sort = MutableStateFlow(Sort.NEXT_EXPECTED)
    val sort: StateFlow<Sort> = _sort

    data class Item(
        val clientId: Long,
        val name: String,
        val phone: String,
        val lastVisit: String?,
        val nextExpected: String?,
        val expectedIntervalDays: Int,
        val status: DueStatus,
        val sortKeyEpochDay: Long?,
    )

    val items: StateFlow<List<Item>> = combine(
        query.debounce(150).distinctUntilChanged().flatMapLatest { searchClientsWithVisits(it) },
        predictionService.settingsFlow,
        filter,
        sort,
    ) { clients, settings, filter, sort ->
        val today = timeProvider.todayLocalDate()
        val computed = clients.map { c ->
            val p = predictionService.compute(c, todayOverride = today, settings = settings)
            Item(
                clientId = c.client.id,
                name = c.client.name,
                phone = c.client.displayPhone,
                lastVisit = p.lastVisit?.toString(),
                nextExpected = p.nextExpectedDate?.toString(),
                expectedIntervalDays = p.expectedIntervalDays,
                status = p.status,
                sortKeyEpochDay = p.nextExpectedDate?.toEpochDay(),
            )
        }

        val filtered = when (filter) {
            Filter.ALL -> computed
            Filter.DUE_SOON -> computed.filter { it.status == DueStatus.DUE_SOON }
            Filter.OVERDUE -> computed.filter { it.status == DueStatus.OVERDUE }
            Filter.NO_VISITS -> computed.filter { it.status == DueStatus.NO_VISITS }
        }

        when (sort) {
            Sort.NAME -> filtered.sortedBy { it.name.lowercase() }
            Sort.NEXT_EXPECTED -> filtered.sortedWith(compareBy<Item> {
                // NO_VISITS last
                if (it.status == DueStatus.NO_VISITS) Long.MAX_VALUE else (it.sortKeyEpochDay ?: Long.MAX_VALUE)
            }.thenBy { it.name.lowercase() })
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setQuery(v: String) { _query.value = v }
    fun setFilter(v: Filter) { _filter.value = v }
    fun setSort(v: Sort) { _sort.value = v }
}
