package com.wolf.clienttracker.data.settings

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "client_tracker_settings")

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private object Keys {
        val onboardingComplete = booleanPreferencesKey("onboarding_complete")
        val globalDefaultIntervalDays = intPreferencesKey("global_default_interval_days")
        val dueSoonWindowDays = intPreferencesKey("due_soon_window_days")
        val intervalsToConsider = intPreferencesKey("intervals_to_consider")
        val notificationsEnabled = booleanPreferencesKey("notifications_enabled")
        val notificationTimeMinutes = intPreferencesKey("notification_time_minutes")

        val lastWorkerRunEpochMillis = longPreferencesKey("last_worker_run_epoch_millis")
        val lastNotificationSentEpochMillis = longPreferencesKey("last_notification_sent_epoch_millis")

        // debug: -1 = system today
        val debugSimulatedTodayEpochDay = longPreferencesKey("debug_simulated_today_epoch_day")
    }

    val onboardingComplete: Flow<Boolean> = context.dataStore.data.map { it[Keys.onboardingComplete] ?: false }

    val globalDefaultIntervalDays: Flow<Int> = context.dataStore.data.map { it[Keys.globalDefaultIntervalDays] ?: 21 }
    val dueSoonWindowDays: Flow<Int> = context.dataStore.data.map { it[Keys.dueSoonWindowDays] ?: 3 }
    val intervalsToConsider: Flow<Int> = context.dataStore.data.map { it[Keys.intervalsToConsider] ?: 5 }

    val notificationsEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.notificationsEnabled] ?: true }
    val notificationTimeMinutes: Flow<Int> = context.dataStore.data.map { it[Keys.notificationTimeMinutes] ?: (10 * 60) }

    val lastWorkerRunEpochMillis: Flow<Long?> = context.dataStore.data.map { it[Keys.lastWorkerRunEpochMillis] }
    val lastNotificationSentEpochMillis: Flow<Long?> = context.dataStore.data.map { it[Keys.lastNotificationSentEpochMillis] }

    val debugSimulatedTodayEpochDay: Flow<Long> = context.dataStore.data.map { it[Keys.debugSimulatedTodayEpochDay] ?: -1L }

    suspend fun setOnboardingComplete(value: Boolean) = context.dataStore.edit { it[Keys.onboardingComplete] = value }

    suspend fun setGlobalDefaultIntervalDays(value: Int) = context.dataStore.edit { it[Keys.globalDefaultIntervalDays] = value.coerceIn(1, 365) }
    suspend fun setDueSoonWindowDays(value: Int) = context.dataStore.edit { it[Keys.dueSoonWindowDays] = value.coerceIn(0, 30) }
    suspend fun setIntervalsToConsider(value: Int) = context.dataStore.edit { it[Keys.intervalsToConsider] = value.coerceIn(3, 10) }

    suspend fun setNotificationsEnabled(value: Boolean) = context.dataStore.edit { it[Keys.notificationsEnabled] = value }
    suspend fun setNotificationTimeMinutes(value: Int) = context.dataStore.edit { it[Keys.notificationTimeMinutes] = value.coerceIn(0, 23 * 60 + 59) }

    suspend fun setLastWorkerRunEpochMillis(value: Long) = context.dataStore.edit { it[Keys.lastWorkerRunEpochMillis] = value }
    suspend fun setLastNotificationSentEpochMillis(value: Long) = context.dataStore.edit { it[Keys.lastNotificationSentEpochMillis] = value }

    suspend fun setDebugSimulatedTodayEpochDay(value: Long) = context.dataStore.edit { it[Keys.debugSimulatedTodayEpochDay] = value }
}
