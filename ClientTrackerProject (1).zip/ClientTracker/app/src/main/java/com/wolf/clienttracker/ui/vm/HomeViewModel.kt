package com.wolf.clienttracker.ui.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wolf.clienttracker.domain.usecase.LogVisitUseCase
import com.wolf.clienttracker.domain.usecase.ObserveAllClientsWithVisitsUseCase
import com.wolf.clienttracker.domain.usecase.SearchClientsWithVisitsUseCase
import com.wolf.clienttracker.domain.prediction.DueStatus
import com.wolf.clienttracker.domain.prediction.PredictionResult
import com.wolf.clienttracker.domain.service.ClientPredictionService
import com.wolf.clienttracker.domain.time.TimeProvider
import com.wolf.clienttracker.ui.common.UiEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Instant
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val observeAllClientsWithVisits: ObserveAllClientsWithVisitsUseCase,
    private val searchClientsWithVisits: SearchClientsWithVisitsUseCase,
    private val logVisitUseCase: LogVisitUseCase,
    private val predictionService: ClientPredictionService,
    private val timeProvider: TimeProvider,
) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query

    private val _events = MutableSharedFlow<UiEvent>()
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    data class DashboardState(
        val overdueCount: Int = 0,
        val dueSoonCount: Int = 0,
        val loggedTodayCount: Int = 0,
        val notificationsDisabledBanner: Boolean = false,
    )

    data class SearchItem(
        val clientId: Long,
        val name: String,
        val phone: String,
        val status: DueStatus,
        val nextExpected: String?,
    )

    val dashboard: StateFlow<DashboardState> = combine(
        observeAllClientsWithVisits(),
        predictionService.settingsFlow,
    ) { clients, settings ->
        val zone = timeProvider.zoneId()
        val today = timeProvider.todayLocalDate()

        val predictions = clients.map { c -> predictionService.compute(c, todayOverride = today, settings = settings) }
        val counts = predictionService.dashboardCounts(predictions)

        val loggedToday = clients.sumOf { c ->
            c.visits.count { it.timestamp.atZone(zone).toLocalDate() == today }
        }

        DashboardState(
            overdueCount = counts.overdue,
            dueSoonCount = counts.dueSoon,
            loggedTodayCount = loggedToday,
            notificationsDisabledBanner = false,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardState())

    val searchResults: StateFlow<List<SearchItem>> = combine(
        query.debounce(150).distinctUntilChanged().flatMapLatest { q -> searchClientsWithVisits(q) },
        predictionService.settingsFlow,
    ) { clients, settings ->
        val today = timeProvider.todayLocalDate()
        clients.take(30).map { c ->
            val p = predictionService.compute(c, todayOverride = today, settings = settings)
            SearchItem(
                clientId = c.client.id,
                name = c.client.name,
                phone = c.client.displayPhone,
                status = p.status,
                nextExpected = p.nextExpectedDate?.toString(),
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setQuery(value: String) {
        _query.value = value
    }

    fun logVisitNow(clientId: Long) {
        viewModelScope.launch {
            val res = logVisitUseCase(clientId, timeProvider.nowInstant(), notes = null)
            if (res.isSuccess) {
                _events.emit(UiEvent.Message("Visit logged."))
            } else {
                _events.emit(UiEvent.Message(res.exceptionOrNull()?.message ?: "Failed to log visit"))
            }
        }
    }
}
