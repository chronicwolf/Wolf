package com.wolf.clienttracker.worker

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.wolf.clienttracker.data.settings.SettingsRepository
import com.wolf.clienttracker.domain.time.TimeProvider
import com.wolf.clienttracker.notifications.NotificationConstants
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.first
import java.time.Duration
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationScheduler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsRepository: SettingsRepository,
    private val timeProvider: TimeProvider,
) {
    private val wm: WorkManager by lazy { WorkManager.getInstance(context) }

    suspend fun scheduleDaily() {
        val enabled = settingsRepository.notificationsEnabled.first()
        if (!enabled) {
            cancel()
            return
        }

        val minutes = settingsRepository.notificationTimeMinutes.first()
        val target = LocalTime.of(minutes / 60, minutes % 60)
        val zone = ZoneId.systemDefault()
        val now = timeProvider.nowInstant().atZone(zone).toLocalDateTime()

        val next = if (now.toLocalTime().isBefore(target) || now.toLocalTime() == target) {
            now.toLocalDate().atTime(target)
        } else {
            now.toLocalDate().plusDays(1).atTime(target)
        }

        val delay = Duration.between(now, next).coerceAtLeast(Duration.ZERO)

        val request = OneTimeWorkRequestBuilder<DueCheckWorker>()
            .setInitialDelay(delay)
            .addTag(NotificationConstants.UNIQUE_WORK_NAME)
            .build()

        wm.enqueueUniqueWork(NotificationConstants.UNIQUE_WORK_NAME, ExistingWorkPolicy.REPLACE, request)
    }

    fun cancel() {
        wm.cancelUniqueWork(NotificationConstants.UNIQUE_WORK_NAME)
    }

    fun enqueueNow() {
        val request = OneTimeWorkRequestBuilder<DueCheckWorker>()
            .addTag(NotificationConstants.UNIQUE_WORK_NAME)
            .build()
        wm.enqueue(request)
    }
}
