package com.wolf.clienttracker.ui.vm

import android.content.Context
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wolf.clienttracker.domain.usecase.GetAllClientsWithVisitsOnceUseCase
import com.wolf.clienttracker.data.settings.SettingsRepository
import com.wolf.clienttracker.domain.prediction.DueStatus
import com.wolf.clienttracker.domain.prediction.PredictionSettings
import com.wolf.clienttracker.domain.service.ClientPredictionService
import com.wolf.clienttracker.domain.time.TimeProvider
import com.wolf.clienttracker.notifications.NotificationHelper
import com.wolf.clienttracker.worker.NotificationScheduler
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import javax.inject.Inject

@HiltViewModel
class DiagnosticsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsRepository: SettingsRepository,
    private val getAllClientsWithVisitsOnce: GetAllClientsWithVisitsOnceUseCase,
    private val predictionService: ClientPredictionService,
    private val timeProvider: TimeProvider,
    private val scheduler: NotificationScheduler,
) : ViewModel() {

    private val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

    data class UiState(
        val zoneId: String,
        val today: String,
        val nowLocal: String,
        val notificationPermission: String,
        val notificationsEnabled: Boolean,
        val nextScheduledEstimate: String,
        val lastWorkerRun: String?,
        val lastNotificationSent: String?,
        val simulatedToday: String,
    )

    val state: StateFlow<UiState> = combine(
        settingsRepository.notificationsEnabled,
        settingsRepository.notificationTimeMinutes,
        settingsRepository.lastWorkerRunEpochMillis,
        settingsRepository.lastNotificationSentEpochMillis,
        settingsRepository.debugSimulatedTodayEpochDay,
    ) { enabled, minutes, lastRun, lastSent, simulatedEpochDay ->
        val zone = ZoneId.systemDefault()
        val today = timeProvider.todayLocalDate()
        val now = timeProvider.nowInstant().atZone(zone).toLocalDateTime()
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            val granted = ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (granted) "granted" else "denied"
        } else {
            "granted"
        }

        val estimate = computeNextEstimate(now, minutes)

        UiState(
            zoneId = zone.id,
            today = today.toString(),
            nowLocal = now.format(formatter),
            notificationPermission = permission,
            notificationsEnabled = enabled,
            nextScheduledEstimate = estimate,
            lastWorkerRun = lastRun?.let { Instant.ofEpochMilli(it).atZone(zone).toLocalDateTime().format(formatter) },
            lastNotificationSent = lastSent?.let { Instant.ofEpochMilli(it).atZone(zone).toLocalDateTime().format(formatter) },
            simulatedToday = if (simulatedEpochDay >= 0) LocalDate.ofEpochDay(simulatedEpochDay).toString() else "(system)",
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState(
        zoneId = ZoneId.systemDefault().id,
        today = timeProvider.todayLocalDate().toString(),
        nowLocal = "",
        notificationPermission = "unknown",
        notificationsEnabled = true,
        nextScheduledEstimate = "",
        lastWorkerRun = null,
        lastNotificationSent = null,
        simulatedToday = "(system)",
    ))

    private fun computeNextEstimate(now: LocalDateTime, minutes: Int): String {
        val target = LocalTime.of(minutes / 60, minutes % 60)
        val next = if (now.toLocalTime().isBefore(target) || now.toLocalTime() == target) {
            now.toLocalDate().atTime(target)
        } else {
            now.toLocalDate().plusDays(1).atTime(target)
        }
        return next.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))
    }

    fun runDueCheckNow() {
        scheduler.enqueueNow()
    }

    fun sendTestNotificationNow() {
        viewModelScope.launch {
            val canNotify = if (Build.VERSION.SDK_INT >= 33) {
                ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
            } else true
            if (!canNotify) return@launch

            val settings = PredictionSettings(
                globalDefaultIntervalDays = settingsRepository.globalDefaultIntervalDays.first(),
                dueSoonWindowDays = settingsRepository.dueSoonWindowDays.first(),
                intervalsToConsider = settingsRepository.intervalsToConsider.first(),
            )
            val clients = getAllClientsWithVisitsOnce()
            val today = timeProvider.todayLocalDate()
            val preds = clients.map { predictionService.compute(it, todayOverride = today, settings = settings) }

            val overdue = clients.zip(preds).filter { it.second.status == DueStatus.OVERDUE }
            val dueSoon = clients.zip(preds).filter { it.second.status == DueStatus.DUE_SOON }
            val names = buildList {
                overdue.forEach { add(it.first.client.name) }
                dueSoon.forEach { add(it.first.client.name) }
            }

            NotificationHelper.postDueSummary(context, overdue.size, dueSoon.size, names)
            settingsRepository.setLastNotificationSentEpochMillis(timeProvider.nowInstant().toEpochMilli())
        }
    }

    fun setSimulatedTodayOrNull(epochDayOrMinus1: Long) {
        viewModelScope.launch {
            settingsRepository.setDebugSimulatedTodayEpochDay(epochDayOrMinus1)
        }
    }
}
