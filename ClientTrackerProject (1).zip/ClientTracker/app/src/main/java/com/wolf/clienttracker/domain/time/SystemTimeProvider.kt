package com.wolf.clienttracker.domain.time

import com.wolf.clienttracker.data.settings.SettingsRepository
import com.wolf.clienttracker.di.ApplicationScope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SystemTimeProvider @Inject constructor(
    private val settingsRepository: SettingsRepository,
    @ApplicationScope private val appScope: CoroutineScope,
) : TimeProvider {

    private val simulatedEpochDay = MutableStateFlow(-1L)

    init {
        appScope.launch {
            settingsRepository.debugSimulatedTodayEpochDay.collectLatest { simulatedEpochDay.value = it }
        }
    }

    override fun nowInstant(): Instant = Instant.now()

    override fun todayLocalDate(): LocalDate {
        val epochDay = simulatedEpochDay.value
        return if (epochDay >= 0) {
            LocalDate.ofEpochDay(epochDay)
        } else {
            LocalDate.now(zoneId())
        }
    }

    override fun zoneId(): ZoneId = ZoneId.systemDefault()
}
