package com.wolf.clienttracker.domain.model

import java.time.Instant

data class Client(
    val id: Long,
    val name: String,
    val normalizedPhone: String,
    val displayPhone: String,
    val notes: String?,
    val createdAt: Instant,
)

data class Visit(
    val id: Long,
    val clientId: Long,
    val timestamp: Instant,
    val notes: String?,
)

data class ClientWithVisits(
    val client: Client,
    val visits: List<Visit>,
)
