package com.wolf.clienttracker.ui.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wolf.clienttracker.ui.common.UiEvent
import com.wolf.clienttracker.ui.vm.AddEditClientViewModel

@Composable
fun AddEditClientScreen(
    clientId: Long?,
    onDone: (Long) -> Unit,
    onCancel: () -> Unit,
    vm: AddEditClientViewModel = hiltViewModel(),
) {
    val snackbarHostState = remember { SnackbarHostState() }

    val name by vm.name.collectAsState()
    val phone by vm.phone.collectAsState()
    val notes by vm.notes.collectAsState()
    val loading by vm.isLoading.collectAsState()

    LaunchedEffect(Unit) {
        vm.events.collect { ev ->
            if (ev is UiEvent.Message) snackbarHostState.showSnackbar(ev.text)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (clientId == null) "Add Client" else "Edit Client") },
                navigationIcon = {
                    IconButton(onClick = onCancel) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                },
                actions = {
                    TextButton(onClick = { vm.save(onDone) }) { Text("Save") }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = vm::setName,
                label = { Text("Name") },
                modifier = Modifier.fillMaxWidth().testTag("client_name"),
                singleLine = true,
            )

            OutlinedTextField(
                value = phone,
                onValueChange = vm::setPhone,
                label = { Text("Phone") },
                modifier = Modifier.fillMaxWidth().testTag("client_phone"),
                singleLine = true,
            )

            OutlinedTextField(
                value = notes,
                onValueChange = vm::setNotes,
                label = { Text("Notes (optional)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
            )
        }
    }
}
