package com.wolf.clienttracker.worker

import android.content.Context
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.wolf.clienttracker.data.repo.ClientRepository
import com.wolf.clienttracker.data.settings.SettingsRepository
import com.wolf.clienttracker.domain.prediction.DueStatus
import com.wolf.clienttracker.domain.prediction.PredictionSettings
import com.wolf.clienttracker.domain.service.ClientPredictionService
import com.wolf.clienttracker.domain.time.TimeProvider
import com.wolf.clienttracker.notifications.NotificationHelper
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first

@HiltWorker
class DueCheckWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val repository: ClientRepository,
    private val predictionService: ClientPredictionService,
    private val settingsRepository: SettingsRepository,
    private val timeProvider: TimeProvider,
    private val scheduler: NotificationScheduler,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val now = timeProvider.nowInstant()
        settingsRepository.setLastWorkerRunEpochMillis(now.toEpochMilli())

        val enabled = settingsRepository.notificationsEnabled.first()
        if (!enabled) {
            scheduler.cancel()
            return Result.success()
        }

        val settings = PredictionSettings(
            globalDefaultIntervalDays = settingsRepository.globalDefaultIntervalDays.first(),
            dueSoonWindowDays = settingsRepository.dueSoonWindowDays.first(),
            intervalsToConsider = settingsRepository.intervalsToConsider.first(),
        )

        val clients = repository.getAllClientsWithVisitsOnce()
        val today = timeProvider.todayLocalDate()
        val predictions = clients.map { c -> predictionService.compute(c, todayOverride = today, settings = settings) }

        val overdue = clients.zip(predictions).filter { it.second.status == DueStatus.OVERDUE }
        val dueSoon = clients.zip(predictions).filter { it.second.status == DueStatus.DUE_SOON }

        val overdueCount = overdue.size
        val dueSoonCount = dueSoon.size

        val canNotify = if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(applicationContext, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        if (canNotify && NotificationHelper.canPostNotifications(applicationContext)) {
            val names = buildList {
                overdue.forEach { add(it.first.client.name) }
                dueSoon.forEach { add(it.first.client.name) }
            }
            NotificationHelper.postDueSummary(applicationContext, overdueCount, dueSoonCount, names)
            settingsRepository.setLastNotificationSentEpochMillis(now.toEpochMilli())
        }

        // schedule next
        scheduler.scheduleDaily()
        return Result.success()
    }
}
