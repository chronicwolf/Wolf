package com.wolf.clienttracker.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.wolf.clienttracker.MainActivity

object NotificationHelper {

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val existing = nm.getNotificationChannel(NotificationConstants.CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    NotificationConstants.CHANNEL_ID,
                    NotificationConstants.CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_DEFAULT,
                ).apply {
                    description = NotificationConstants.CHANNEL_DESC
                }
                nm.createNotificationChannel(channel)
            }
        }
    }

    fun canPostNotifications(context: Context): Boolean {
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    fun postDueSummary(
        context: Context,
        overdueCount: Int,
        dueSoonCount: Int,
        lines: List<String>,
    ) {
        ensureChannel(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            action = NotificationConstants.ACTION_OPEN_DUE
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0),
        )

        val inbox = NotificationCompat.InboxStyle()
        for (line in lines.take(8)) inbox.addLine(line)
        if (lines.size > 8) inbox.addLine("+ ${lines.size - 8} more")

        val notification = NotificationCompat.Builder(context, NotificationConstants.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Clients Due")
            .setContentText("Overdue: $overdueCount, Due soon: $dueSoonCount")
            .setStyle(inbox)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(context).notify(1001, notification)
    }
}
