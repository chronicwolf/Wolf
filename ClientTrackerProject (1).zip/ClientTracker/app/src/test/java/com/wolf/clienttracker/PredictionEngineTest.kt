package com.wolf.clienttracker

import com.wolf.clienttracker.domain.prediction.DueStatus
import com.wolf.clienttracker.domain.prediction.PredictionEngine
import com.wolf.clienttracker.domain.prediction.PredictionSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.*

class PredictionEngineTest {

    private val engine = PredictionEngine()
    private val zone = ZoneId.of("Asia/Bahrain")

    private fun instantAt(date: LocalDate, hour: Int = 10): Instant {
        return date.atTime(hour, 0).atZone(zone).toInstant()
    }

    @Test
    fun median_correctness_odd_even() {
        val settings = PredictionSettings(globalDefaultIntervalDays = 21, dueSoonWindowDays = 3, intervalsToConsider = 5)
        val today = LocalDate.of(2026, 2, 19)

        // Odd count gaps: [3,5,8] => median = 5
        run {
            val base = today.minusDays(20)
            val dates = listOf(
                base,
                base.plusDays(3),
                base.plusDays(8),
                base.plusDays(16),
            )
            // gaps 3,5,8
            val r = engine.predict(dates.map { instantAt(it) }, zone, today, settings.copy(intervalsToConsider = 10))
            assertEquals(listOf(3,5,8), r.gapsUsed)
            assertEquals(5, r.expectedIntervalDays)
        }

        // Even count gaps: [3,5,8,10] => median = 6.5 rounded => 7
        run {
            val base = today.minusDays(30)
            val dates = listOf(
                base,
                base.plusDays(3),
                base.plusDays(8),
                base.plusDays(16),
                base.plusDays(26),
            )
            // gaps 3,5,8,10
            val r = engine.predict(dates.map { instantAt(it) }, zone, today, settings.copy(intervalsToConsider = 10))
            assertEquals(listOf(3,5,8,10), r.gapsUsed)
            assertEquals(7, r.expectedIntervalDays)
        }
    }

    @Test
    fun expected_interval_cases() {
        val today = LocalDate.of(2026, 2, 19)
        val settings = PredictionSettings(globalDefaultIntervalDays = 21, dueSoonWindowDays = 3, intervalsToConsider = 5)

        // 0 visits
        val r0 = engine.predict(emptyList(), zone, today, settings)
        assertEquals(DueStatus.NO_VISITS, r0.status)
        assertEquals(21, r0.expectedIntervalDays)

        // 1 visit -> global default
        val r1 = engine.predict(listOf(instantAt(today.minusDays(1))), zone, today, settings)
        assertEquals(21, r1.expectedIntervalDays)

        // 2 distinct visit days -> 1 gap
        val r2 = engine.predict(listOf(instantAt(today.minusDays(10)), instantAt(today)), zone, today, settings)
        assertEquals(10, r2.expectedIntervalDays)

        // multiple gaps -> median of last N
        val visitDates = listOf(
            today.minusDays(40),
            today.minusDays(30), // gap 10
            today.minusDays(20), // gap 10
            today.minusDays(10), // gap 10
            today.minusDays(4),  // gap 6
            today.minusDays(1),  // gap 3
        )
        // gaps: 10,10,10,6,3. last N=5 => all. median=10
        val r3 = engine.predict(visitDates.map { instantAt(it) }, zone, today, settings.copy(intervalsToConsider = 5))
        assertEquals(listOf(10,10,10,6,3), r3.gapsUsed)
        assertEquals(10, r3.expectedIntervalDays)

        // >N gaps uses last N
        val visitDates2 = listOf(
            today.minusDays(70),
            today.minusDays(60), //10
            today.minusDays(50), //10
            today.minusDays(40), //10
            today.minusDays(30), //10
            today.minusDays(20), //10
            today.minusDays(10), //10
            today.minusDays(4),  //6
            today.minusDays(1),  //3
        )
        // gaps: 10,10,10,10,10,10,6,3. last 5 => 10,10,10,6,3 => median=10
        val r4 = engine.predict(visitDates2.map { instantAt(it) }, zone, today, settings.copy(intervalsToConsider = 5))
        assertEquals(listOf(10,10,10,6,3), r4.gapsUsed)
        assertEquals(10, r4.expectedIntervalDays)
    }

    @Test
    fun same_day_multiple_visits_do_not_create_zero_day_gap() {
        val today = LocalDate.of(2026, 2, 19)
        val settings = PredictionSettings(21, 3, 5)
        val date = today.minusDays(5)
        val instants = listOf(instantAt(date, 9), instantAt(date, 18))
        val r = engine.predict(instants, zone, today, settings)
        assertTrue(r.gapsUsed.isEmpty())
        assertEquals(21, r.expectedIntervalDays)
        assertEquals(date.plusDays(21), r.nextExpectedDate)
    }

    @Test
    fun due_status_boundaries() {
        val settings = PredictionSettings(globalDefaultIntervalDays = 21, dueSoonWindowDays = 3, intervalsToConsider = 5)

        // Setup: last visit 10 days ago, gap=10 => expected interval 10 => nextExpected = last+10
        val last = LocalDate.of(2026, 2, 10)
        val prev = LocalDate.of(2026, 1, 31)
        val nextExpected = last.plusDays(10)

        // today == nextExpected => DUE_SOON
        run {
            val today = nextExpected
            val r = engine.predict(listOf(instantAt(prev), instantAt(last)), zone, today, settings)
            assertEquals(DueStatus.DUE_SOON, r.status)
        }

        // today == nextExpected - window => DUE_SOON
        run {
            val today = nextExpected.minusDays(settings.dueSoonWindowDays.toLong())
            val r = engine.predict(listOf(instantAt(prev), instantAt(last)), zone, today, settings)
            assertEquals(DueStatus.DUE_SOON, r.status)
        }

        // today == nextExpected + 1 => OVERDUE
        run {
            val today = nextExpected.plusDays(1)
            val r = engine.predict(listOf(instantAt(prev), instantAt(last)), zone, today, settings)
            assertEquals(DueStatus.OVERDUE, r.status)
        }
    }

    @Test
    fun likely_window_rules() {
        val today = LocalDate.of(2026, 2, 19)
        val settings = PredictionSettings(21, 3, 5)

        // Need >=3 gaps to enable window.
        val visitDates = listOf(
            today.minusDays(30),
            today.minusDays(25), // 5
            today.minusDays(18), // 7
            today.minusDays(10), // 8
        )
        val r = engine.predict(visitDates.map { instantAt(it) }, zone, today, settings)
        assertTrue(r.hasEnoughHistoryForWindow)
        assertTrue(r.likelyWindow != null)
    }
}
