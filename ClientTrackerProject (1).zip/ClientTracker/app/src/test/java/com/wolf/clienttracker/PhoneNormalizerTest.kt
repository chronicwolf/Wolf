package com.wolf.clienttracker

import com.wolf.clienttracker.domain.phone.PhoneNormalizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class PhoneNormalizerTest {

    @Test
    fun normalizes_examples() {
        val r = PhoneNormalizer.normalize("+973 33-123-456")
        assertNotNull(r)
        assertEquals("+97333123456", r!!.normalizedPhone)
    }

    @Test
    fun strips_noise() {
        val r = PhoneNormalizer.normalize("(973) 33.123.456")
        assertNotNull(r)
        assertEquals("97333123456", r!!.normalizedPhone)
    }

    @Test
    fun empty_returns_null() {
        assertNull(PhoneNormalizer.normalize("   "))
    }

    @Test
    fun keeps_single_leading_plus_only() {
        val r = PhoneNormalizer.normalize("++ +973 33123456")
        assertNotNull(r)
        assertEquals("+97333123456", r!!.normalizedPhone)
    }
}
