package org.gradle.wrapper;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Minimal, self-contained Gradle wrapper implementation.
 *
 * This is NOT the official Gradle wrapper jar. It implements the core behavior needed for this project:
 * - read gradle/wrapper/gradle-wrapper.properties
 * - download the specified Gradle distribution
 * - unzip into ~/.gradle/wrapper/dists
 * - launch Gradle with the provided arguments
 */
public final class GradleWrapperMain {

    public static void main(String[] args) throws Exception {
        Path projectDir = Paths.get(System.getProperty("user.dir")).toAbsolutePath().normalize();
        Path propertiesPath = projectDir.resolve("gradle/wrapper/gradle-wrapper.properties");
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(propertiesPath)) {
            props.load(in);
        }

        String distributionUrl = require(props, "distributionUrl");
        String distributionFileName = distributionUrl.substring(distributionUrl.lastIndexOf('/') + 1);
        String gradleVersion = extractGradleVersion(distributionFileName);

        Path gradleUserHome = Paths.get(System.getProperty("user.home"), ".gradle");
        Path distsRoot = gradleUserHome.resolve("wrapper/dists");
        Files.createDirectories(distsRoot);

        String urlHash = sha256Hex(distributionUrl);
        Path distDir = distsRoot.resolve("gradle-" + gradleVersion).resolve(urlHash);
        Path markerFile = distDir.resolve(".unzipped");

        if (!Files.exists(markerFile)) {
            Files.createDirectories(distDir);
            Path zipPath = distDir.resolve(distributionFileName);
            if (!Files.exists(zipPath)) {
                System.out.println("Downloading Gradle distribution: " + distributionUrl);
                download(distributionUrl, zipPath);
            }
            System.out.println("Unzipping Gradle distribution...");
            unzip(zipPath, distDir);
            Files.writeString(markerFile, "ok", StandardCharsets.UTF_8);
        }

        Path gradleHome = findGradleHome(distDir, gradleVersion);
        Path launcherJar = gradleHome.resolve("lib/gradle-launcher-" + gradleVersion + ".jar");
        if (!Files.exists(launcherJar)) {
            throw new FileNotFoundException("Gradle launcher jar not found: " + launcherJar);
        }

        List<String> cmd = new ArrayList<>();
        cmd.add(findJava());
        cmd.add("-classpath");
        cmd.add(launcherJar.toString());
        cmd.add("org.gradle.launcher.GradleMain");
        cmd.addAll(Arrays.asList(args));

        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.directory(projectDir.toFile());
        pb.inheritIO();
        Process p = pb.start();
        int exit = p.waitFor();
        System.exit(exit);
    }

    private static String require(Properties props, String key) {
        String v = props.getProperty(key);
        if (v == null || v.isBlank()) throw new IllegalStateException("Missing " + key + " in gradle-wrapper.properties");
        return v.trim();
    }

    private static String extractGradleVersion(String distributionFileName) {
        // expects gradle-<version>-bin.zip or gradle-<version>-all.zip
        if (!distributionFileName.startsWith("gradle-") || !distributionFileName.endsWith(".zip")) {
            throw new IllegalArgumentException("Unexpected distribution file name: " + distributionFileName);
        }
        String core = distributionFileName.substring("gradle-".length(), distributionFileName.length() - ".zip".length());
        int dash = core.lastIndexOf('-');
        if (dash <= 0) throw new IllegalArgumentException("Unexpected distribution file name: " + distributionFileName);
        return core.substring(0, dash);
    }

    private static Path findGradleHome(Path distDir, String version) throws IOException {
        // the zip contains a top-level directory: gradle-<version>/
        Path candidate = distDir.resolve("gradle-" + version);
        if (Files.exists(candidate)) return candidate;
        // fallback: search
        try (var stream = Files.list(distDir)) {
            return stream.filter(p -> Files.isDirectory(p) && p.getFileName().toString().startsWith("gradle-" + version))
                    .findFirst()
                    .orElseThrow(() -> new FileNotFoundException("Gradle home not found under " + distDir));
        }
    }

    private static void download(String url, Path out) throws IOException {
        URL u = new URL(url);
        HttpURLConnection conn = (HttpURLConnection) u.openConnection();
        conn.setConnectTimeout((int) Duration.ofSeconds(20).toMillis());
        conn.setReadTimeout((int) Duration.ofSeconds(60).toMillis());
        conn.setInstanceFollowRedirects(true);
        int code = conn.getResponseCode();
        if (code >= 400) {
            throw new IOException("HTTP " + code + " downloading " + url);
        }
        long total = conn.getContentLengthLong();
        try (InputStream in = new BufferedInputStream(conn.getInputStream());
             OutputStream os = new BufferedOutputStream(Files.newOutputStream(out, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING))) {
            byte[] buf = new byte[8192];
            long read = 0;
            long lastPrint = 0;
            int n;
            while ((n = in.read(buf)) >= 0) {
                os.write(buf, 0, n);
                read += n;
                if (total > 0 && (read - lastPrint) > 5_000_000) {
                    lastPrint = read;
                    System.out.printf(Locale.US, "  %.1f%%\n", (read * 100.0) / total);
                }
            }
        }
    }

    private static void unzip(Path zip, Path destDir) throws IOException {
        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(Files.newInputStream(zip)))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                Path outPath = destDir.resolve(entry.getName()).normalize();
                if (!outPath.startsWith(destDir)) {
                    throw new IOException("Zip slip detected: " + entry.getName());
                }
                if (entry.isDirectory()) {
                    Files.createDirectories(outPath);
                } else {
                    Files.createDirectories(outPath.getParent());
                    try (OutputStream os = new BufferedOutputStream(Files.newOutputStream(outPath, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING))) {
                        zis.transferTo(os);
                    }
                }
                zis.closeEntry();
            }
        }
    }

    private static String sha256Hex(String s) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(s.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private static String findJava() {
        String javaHome = System.getenv("JAVA_HOME");
        if (javaHome != null && !javaHome.isBlank()) {
            Path java = Paths.get(javaHome, "bin", "java");
            if (Files.exists(java)) return java.toString();
        }
        return "java";
    }
}
